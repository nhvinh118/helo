
from pset_4.cli import main


def test_main():
    main([])
