
Changelog
=========

0.0.0 (2019-03-14)
------------------

* First release on PyPI.
