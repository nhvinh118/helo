========
Overview
========

.. start-badges

.. list-table::
    :stub-columns: 1

    * - docs
      - |docs|
    * - tests
      - | |travis| |appveyor|
        |
    * - package
      - | |version| |wheel| |supported-versions| |supported-implementations|
        | |commits-since|
.. |docs| image:: https://readthedocs.org/projects/2019sp-pset-4-nhvinh118/badge/?style=flat
    :target: https://readthedocs.org/projects/2019sp-pset-4-nhvinh118
    :alt: Documentation Status

.. |travis| image:: https://travis-ci.org/csci-e-29/2019sp-pset-4-nhvinh118.svg?branch=master
    :alt: Travis-CI Build Status
    :target: https://travis-ci.org/csci-e-29/2019sp-pset-4-nhvinh118

.. |appveyor| image:: https://ci.appveyor.com/api/projects/status/github/csci-e-29/2019sp-pset-4-nhvinh118?branch=master&svg=true
    :alt: AppVeyor Build Status
    :target: https://ci.appveyor.com/project/csci-e-29/2019sp-pset-4-nhvinh118

.. |version| image:: https://img.shields.io/pypi/v/pset-4.svg
    :alt: PyPI Package latest release
    :target: https://pypi.org/project/pset-4

.. |commits-since| image:: https://img.shields.io/github/commits-since/csci-e-29/2019sp-pset-4-nhvinh118/v0.0.0.svg
    :alt: Commits since latest release
    :target: https://github.com/csci-e-29/2019sp-pset-4-nhvinh118/compare/v0.0.0...master

.. |wheel| image:: https://img.shields.io/pypi/wheel/pset-4.svg
    :alt: PyPI Wheel
    :target: https://pypi.org/project/pset-4

.. |supported-versions| image:: https://img.shields.io/pypi/pyversions/pset-4.svg
    :alt: Supported versions
    :target: https://pypi.org/project/pset-4

.. |supported-implementations| image:: https://img.shields.io/pypi/implementation/pset-4.svg
    :alt: Supported implementations
    :target: https://pypi.org/project/pset-4


.. end-badges

Pset 4

* Free software: MIT license

Installation
============

::

    pip install pset-4

Documentation
=============


https://2019sp-pset-4-nhvinh118.readthedocs.io/


Development
===========

To run the all tests run::

    tox

Note, to combine the coverage data from all the tox environments run:

.. list-table::
    :widths: 10 90
    :stub-columns: 1

    - - Windows
      - ::

            set PYTEST_ADDOPTS=--cov-append
            tox

    - - Other
      - ::

            PYTEST_ADDOPTS=--cov-append tox
