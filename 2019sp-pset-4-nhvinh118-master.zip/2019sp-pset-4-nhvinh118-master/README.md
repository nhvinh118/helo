# Pset 4

https://travis-ci.com/csci-e-29/2019sp-pset-4-nhvinh118.svg?token=mUqdw2c9UzD11cjx6vtN&branch=master
/home/hoang/Documents/E29/2019sp-pset-4-nhvinh118/data/image/neuralluigi.jpg
/home/hoang/Documents/E29/2019sp-pset-4-nhvinh118/data/image/neuralneighborhood.jpg

Pytorch has implemented a neat algorithm for artistic style transfer
[here](https://github.com/pytorch/examples/tree/master/fast_neural_style). For
this pset, we will be using a pre-trained model for styling our own input image,
and we will do so in a [Luigi](https://luigi.readthedocs.io/en/stable/)
workflow.

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
**Table of Contents**  *generated with [DocToc](https://github.com/thlorenz/doctoc)*

- [Setup](#setup)
  - [Render your pset 4 repo](#render-your-pset-4-repo)
    - [Installations](#installations)
    - [AWS credentials](#aws-credentials)
  - [Styling Code](#styling-code)
    - [Fixing their work](#fixing-their-work)
  - [Pre-Trained Model & Input Content Image](#pre-trained-model--input-content-image)
  - [Limit builds on Travis](#limit-builds-on-travis)
- [Problems (45 points)](#problems-45-points)
  - [A new atomic write (10 points)](#a-new-atomic-write-10-points)
  - [External Tasks (5 points)](#external-tasks-5-points)
  - [Copying S3 files locally (15 points)](#copying-s3-files-locally-15-points)
  - [Stylizing (15 points)](#stylizing-15-points)
    - [Option A) `ExternalProgramTask`](#option-a-externalprogramtask)
    - [Option B) Direct python](#option-b-direct-python)
  - [Running it](#running-it)
  - [Your Own Image (points in quiz)](#your-own-image-points-in-quiz)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## Setup

### Render your pset 4 repo

Using cookiecutter, as we've done in the past, navigate to the directory above
your local cookiecutter repo, and do:

```bash
cookiecutter cookiecutter-csci-pset-USERNAME/
```

With the following defaults, as you would expect:

| Param | Value |  
|-|-|  
| project_name | `Pset 4` |  
| repo_name | (should default to `2019sp-pset-4-USERNAME`) |  
| package_name | (should default to `pset_4`) |  

#### Installations

You will need luigi, pytorch, torchvision, and boto3 for this problem set.
Perform the following commands for the installations within your
`2019sp-pset-4-USERNAME ` folder.

```bash
pipenv install luigi torch torchvision boto3
```

You can now perform your first push to github:

```bash
git init
git add --all
git commit -m "Add initial project skeleton."
git remote add origin git@github.com:csci-e-29/2019sp-pset-4-USERNAME.git
git fetch
git merge origin/master --allow-unrelated-histories
git push -u origin master
```

#### AWS credentials

As in previous problem sets, add your AWS credentials to an .env file as well as
in Travis settings.


### Styling Code

We will also need the `neural_styles` folder in the [pytorch
examples](https://github.com/pytorch/examples/tree/master/fast_neural_style)
repo. This contains the code necessary to stylize the image of our choosing. You
can either clone/download the repo and manually place the `neural_styles`
package into `2019sp-pset-4-USERNAME/src`, or copy it over from AWS as follows:

```bash
cd 2019sp-pset-4-USERNAME/
aws s3 cp s3://cscie29-data/pset4/neural_style src/neural_style --recursive
```

Note that we are copying the 5 files into the `src/neural_style` as a separate
importable package next to the `pset_4` package.  It should look like:

```
repo/
  src/
    pset_4/
      ...
    neural_style/
      __init__.py
      neural_style.py
      ...
```

#### Fixing their work
Depending on the solution you choose below, you may need to modify some of the
original code.  Here are two known issues:

1. The code does not use [relative
imports](https://realpython.com/absolute-vs-relative-python-imports/).  You may
need to modify `neural_style.py` to fix all imports to other modules in
`neural_style`.

2. Calling `python neural_style/neural_style.py` inside a package has problems.
You can add a `__main__.py`, import `main` from `neural_style.py`, and call it
there, similar to your cookiecutter template.  When done, you should be able to
run the code directly via `python -m neural_style`.

### Pre-Trained Model & Input Content Image

We have provided pre-trained models from the pytorch/examples repo, and a
content image for us to stylize. We will be copying them from S3 via Luigi, so
don't copy them over quite yet. They are located at
`s3://cscie29-data/pset4/model/rain_princess.pth` and
`s3://cscie29-data/pset4/data/luigi.jpg`.

***Ensure `data/` is in your `.gitignore`!***

### Limit builds on Travis

Because we're pulling a bit more data and running things with a bit more
computation, ***ensure you only download models and run stylization on master***
for your Travis builds. You should minimize the commits there as well; try to
get everything working locally on develop or a feature branch before releasing
to master.

## Problems (45 points)

Let's get started on our [Luigi](https://luigi.readthedocs.io/en/stable/)
workflow.

One way of structuring your code is to have all Luigi tasks isolated.  Create a
sub-package `pset_4.tasks` for this purpose.  This should contain very little
other code, but may import whatever it needs.

### A new atomic write (10 points)

NB: if you get stuck on this part, you can continue the other sections by using
`Target.path` non-atomically before coming back to finish this.

Luigi implements atomic writing quite well within its `Target` classes.
However, one feature it does not handle is preserving the suffix of the output
target in the temporary file.  This will be a problem for this pset, because we
will be using image utilities that determine the file format from the extension.

In `pset_utils`, create a new module `pset_utils.luigi.target` with something
like the following:

```python
from luigi.local_target import LocalTarget, atomic_file


class suffix_preserving_atomic_file(atomic_file):
    def generate_tmp_path(self, path):
        ...


class BaseAtomicProviderLocalTarget(LocalTarget):
    # Allow some composability of atomic handling
    atomic_provider = atomic_file

    def open(self, mode='r'):
        # leverage super() as well as modifying any code in LocalTarget
        # to use self.atomic_provider rather than atomic_file
        ...

    @contextmanager
    def temporary_path(self):
        # NB: unclear why LocalTarget doesn't use atomic_file in its implementation
        self.makedirs()
        with self.atomic_provider(self.path) as af:
            yield af.tmp_path


class SuffixPreservingLocalTarget(BaseAtomicProviderLocalTarget):
    atomic_provider = suffix_preserving_atomic_file
```

### External Tasks (5 points)

Note that we are essentially trying to run the following Stylizing command:

```bash
python neural_style/neural_style.py eval --content-image </path/to/content/image> --model </path/to/saved/model> --output-image </path/to/output/image> --cuda 0
```

Think about the dependency graph:

- We have a model on S3 (s3://cscie29-data/pset4/model/rain_princess.pth)
- We have an input image on S3 (s3://cscie29-data/pset4/data/luigi.jpg)
- We have to stylize the image given the pre-trained model

For each of the two first points, create a [Luigi External
Task](https://luigi.readthedocs.io/en/stable/api/luigi.task.html#luigi.task.ExternalTask)
that returns the [S3
target](https://luigi.readthedocs.io/en/stable/api/luigi.contrib.s3.html#luigi.contrib.s3.S3Target)
where those files are located.

You should keep these together in a submodule named `pset_03.tasks.data`. These
should be `ExternalTask`'s since we never run them - rather they should have
just been provided.

`pset_4.tasks.data`:

```python
import os

from luigi import ExternalTask, Parameter, Task
from luigi.contrib.s3 import S3Target


class ContentImage(ExternalTask):
    IMAGE_ROOT = ... # Root S3 path, as a constant

    # Name of the image
    image = Parameter(...) # Filename of the image under the root s3 path

    def output(self):
        # return the S3Target of the image


class SavedModel(ExternalTask):
    MODEL_ROOT = ...

    model = Parameter(...) # Filename of the model

    def output(self):
        # return the S3Target of the model
```

***NB***: Luigi treats binary files differently than the standard
`open(mode='wb')`. You should use the `format` kwarg to any `Target` and use
`luigi.format.Nop` to indicate a binary file you might read or write directly.
Otherwise, luigi will assume it can open the file in text mode.  If you see
errors related to unicode decoding, it's because you need to specify the format.

To test that Luigi can read the files, you can run the following:

```bash
luigi --module pset_4.tasks.data ContentImage --local-scheduler --image luigi.jpg
```

... which has the same effect as adding the following code to `main` in
`pset_4.cli` and running `python3 -m pset_4`

```python
build([
    ContentImage(
        image='luigi.jpg'
    )], local_scheduler=True)
```

### Copying S3 files locally (15 points)

Ideally, we wouldn't need to copy files locally - we could read directly from
the remote.  However, to cut down on bandwidth and to simplify the interfacing
code, we'll cache the files and models locally.

In `pset_4.tasks.data`, use `luigi.Task` to perform this functionality.

What is the general pattern here?  Try to restructure and/or commit some code to
`pset_utils` rather than solving this copy problem uniquely for this pset.

```python
class CopyS3ModelLocally(Task):
    MODEL_ROOT = os.path.join('data', 'model')
    model = ... #luigi parameter

    def requires(self):
        # Depends on the SavedModel ExternalTask being complete
        # i.e. the file must exist on S3 in order to copy it locally
        ...

    def output(self):
        ...

    def run(self):
        # Use self.output() and self.input() targets to atomically copy
        # the file locally!

class CopyS3ImageLocally(Task):
    IMAGE_ROOT = os.path.join('data', 'image')
    image = ...

    def requires(self):
        # Depends on the ContentImage ExternalTask being complete

    def output(self):
        ...

    def run(self):
        # Use self.output() and self.input() targets to atomically copy
        # the file locally!
```

Again you can run this via, for example:

```bash
luigi --module pset_4.tasks.data CopyS3ImageLocally --local-scheduler
```

**DO NOT CALL `CopyS3ImageLocally().run()` directly**.  This will bypass the
scheduler and ignore the dependencies, etc.

Also, note that once luigi successfully writes an output, the task will not
rerun unless you delete that file!  If you made a mistake, delete the output
file, change the code, and rerun.

### Stylizing (15 points)

Now let's create a task that does the equivalent of the following in luigi:

```bash
python neural_style/neural_style.py eval --content-image </path/to/content/image> --model </path/to/saved/model> --output-image </path/to/output/image> --cuda 0
```

You have two options for implementing this.  Both will require some structure
within `pset_4.tasks.stylize`:

```python
import luigi
from pset_utils.luigi.target import SuffixPreservingLocalTarget
from .data import CopyS3ModelLocally, CopyS3ImageLocally

class Stylize(...):
    model = ...
    image = ...

    def requires(self):
        return {
            'image': ...,
            'model': ...
        }

    def output(self):
        # return SuffixPreservingLocalTarget of the stylized image
```

In both cases, you need to ensure the output is written atomically.  You may
want to consider [using
target.temporary_path()](https://luigi.readthedocs.io/en/stable/api/luigi.target.html#luigi.target.FileSystemTarget.temporary_path).

#### Option A) `ExternalProgramTask`
This will entail an
[ExternalProgramTask](https://luigi.readthedocs.io/en/stable/api/luigi.contrib.external_program.html#luigi.contrib.external_program.ExternalProgramTask)

For a good example of this executed, see this [blog
post](https://markhneedham.com/blog/2017/03/25/luigi-externalprogramtask-example-converting-json-csv/).

```python
from luigi.contrib.external_program import ExternalProgramTask

class Stylize(ExternalProgramTask):
    ...
    def program_args(self):
        # Be sure to use self.temp_output_path
        return ['python', ...]

    def run(self):
        # You must set up an atomic write!
        # (use self.output().path if you can't get that working)
        with self.output().temporary_path() as self.temp_output_path:
            super().run()
```

#### Option B) Direct python

Directly call, copy, or modify the code in `neural_style.neural_style.stylize`:

```python
from neural_style.neural_style import stylize

class Stylize(Task):
    ...
    def run(self):
        # For example
        inputs = self.input()
        with self.output().temporary_path() as temp_output_path:
            class args:
                content_image = inputs['image'].path
                output_image = temp_output_path
                ...
            stylize(args)
```

### Running it

So that travis can test this via `python3 -m pset_4`, ensure you run `build`
within the `main()` function of `pset4.cli`.  Travis should run `luigi.jpg` with
any of the models.

Optionally, you can add parameterization via argparse to help you play around
with your own image and varying styles.  Something like:

```python
from luigi import build

from .tasks.stylize import Stylize

parser = ...
parser.add_argument("-i", "--image", default=...)
parser.add_argument("-m", "--model", default=...)


def main(args=None):
    ...
    build([
        Stylize(image=args.image, model=args.model)
    ], local_scheduler=True)
```

Note that for testing purposes, you can also do the following (from
`2019sp-pset-4-USERNAME/`) with the same functionality:

```bash
luigi --module pset_4.tasks.stylize Stylize --local-scheduler
```

### Your Own Image (points in quiz)

Instead of the image provided, find an image of your choosing! You are going to
stylize it.

***The filename should be your hashed github id!***

Note that it should be shrunk a bit - native size images from cell phones (eg
8mp) will take a long time to render and may not look good.  You can resize the
image (manually or any tool you wish, or using `pillow` in your repo) to about
500px on the longest edge.

You may pick any of the pretrained models for styling (see them in the examples
repo or  via `aws s3 ls s3://cscie29-data/pset4/model/`).

Because of the atomic workflow, you can simply copy your image into your local
`data/image` directory.  Luigi will detect it there and not try to download it
from S3.

We will not run CI/CD for your image.  Run it locally and upload the result to
the answers quiz.  ***Never commit an image or model to git***.
