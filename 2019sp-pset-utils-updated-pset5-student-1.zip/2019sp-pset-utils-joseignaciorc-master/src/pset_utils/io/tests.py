#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `pset_1` package."""

import os
from tempfile import TemporaryDirectory, NamedTemporaryFile
from unittest import TestCase, mock

from ..io import atomic_write

import hashlib

class FakeFileFailure(IOError):
    pass


class AtomicWriteTests(TestCase):

    def test_atomic_write(self):
        """Ensure file exists after being written successfully"""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            with atomic_write(fp, 'w') as f:
                assert not os.path.exists(fp)
                tmpfile = f.name
                f.write('asdf')

            assert not os.path.exists(tmpfile)
            assert os.path.exists(fp)

            with open(fp) as f:
                self.assertEqual(f.read(), 'asdf')

    def test_atomic_failure(self):
        """Ensure that file does not exist after failure during write"""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            with self.assertRaises(FakeFileFailure):
                with atomic_write(fp, 'w') as f:
                    tmpfile = f.name
                    assert os.path.exists(tmpfile)
                    raise FakeFileFailure()

            assert not os.path.exists(tmpfile)
            assert not os.path.exists(fp)

    def test_file_exists(self):
        """Ensure an error is raised when a file exists"""
        existing_file=NamedTemporaryFile()
        with self.assertRaises(FileExistsError):
            with atomic_write(existing_file.name, 'w') as f:
                f.write('asdf')



    def test_dir_exists(self):
        """Ensure an error is raised when a dir exists"""
        existing_dir=TemporaryDirectory()
        with self.assertRaises(FileExistsError):
            with atomic_write(existing_dir.name, 'w') as f:
                f.write('asdf')

    def test_extension_is_preserved(self):
        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            with atomic_write(fp, 'w') as f:
                f.name.endswith(".txt")
                print(f.name)

    def test_atomic_write_as_filename(self):
        """Ensure file exists after being written successfully"""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdfj.txt')

            with atomic_write(fp, 'w', as_file=False) as f:
                assert not os.path.exists(fp)
                tmpfile = f
                open(f,'w').write('asdfjk')

            assert not os.path.exists(tmpfile)
            assert os.path.exists(fp)

            with open(fp) as f:
                self.assertEqual(f.read(), 'asdfjk')
