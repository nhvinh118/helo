from contextlib import contextmanager
import os
import io
import tempfile

from atomicwrites import atomic_write as _backend_writer, AtomicWriter


class SuffixWriter(AtomicWriter):

    def get_fileobject(self, dir=None, **kwargs):
        '''Return the temporary file to use.'''
        if dir is None:
            dir = os.path.normpath(os.path.dirname(self._path))
        descriptor, name = tempfile.mkstemp(suffix="TEMPORARY_"+os.path.basename(self._path), prefix=None,
                                            dir=dir)

        os.close(descriptor)
        kwargs['mode'] = self._mode
        kwargs['file'] = name
        return io.open(**kwargs)


@contextmanager
def atomic_write(file_path, mode='w', as_file=True, new_default='asdf', **kwargs):
    """
    Write a file atomically

    :param file_path: str or :class:`os.PathLike` target to write

    :param bool as_file:  if True, the yielded object is a :class:File.
        (eg, what you get with `open(...)`).  Otherwise, it will be the
        temporary file path string

    :param new_default: unused. Kept for compatibility.

    :param kwargs: anything else needed to open the file

    :raises: FileExistsError if target exists

    Example::

        with atomic_write("hello.txt") as f:
            f.write("world!")

    """

    with _backend_writer(file_path, writer_cls=SuffixWriter, mode=mode, **kwargs) as f:
        if as_file:
            yield f
        else:
            yield f.name
