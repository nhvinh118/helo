import unittest
import tempfile
import os
from luigi import ExternalTask, Task, Parameter, LocalTarget, build
from pset_utils.luigi.task import Requirement, Requires, TargetOutput


class RequiresAndRequirementsTest(unittest.TestCase):
    def test_requires_requirements_basic_example(self):
        """Basic example of Requires and Requirements, copied directly from Pset-5"""

        class OtherTask(Task):
            ...

        class MyTask(Task):
            # Replace task.requires()
            requires = Requires()
            other = Requirement(OtherTask)

            def run(self):
                # Convenient access here...
                with self.other.output().open('r') as f:
                    ...

        self.assertDictEqual(MyTask().requires(), {'other': OtherTask()})



    def test_requires_requirements_luigi_flow(self):
        """Luigi workflow, including requirements that have paramenters ('tmp_dir' parameter in this case)"""

        class MockInput1(ExternalTask):
            tmp_dir: str = Parameter()

            def output(self):
                return LocalTarget(os.path.join(self.tmp_dir, "test1.input.txt"))

        class MockInput2(ExternalTask):
            tmp_dir: str = Parameter()

            def output(self):
                return LocalTarget(os.path.join(self.tmp_dir, "test2.input.txt"))

        class MainTask(Task):
            tmp_dir: str = Parameter()

            requires = Requires()
            req1 = Requirement(MockInput1)
            req2 = Requirement(MockInput2)

            def output(self):
                return LocalTarget(os.path.join(self.tmp_dir, "test.output.txt"), )

            def run(self):
                with self.input()['req1'].open('r') as inp1_file:
                    inp1_contents = inp1_file.read()

                with self.input()['req2'].open('r') as inp2_file:
                    inp2_contents = inp2_file.read()

                with self.output().open('w') as out_file:
                    out_file.write(inp1_contents + inp2_contents)

        with tempfile.TemporaryDirectory() as tmp_directory:
            with open(os.path.join(tmp_directory, "test1.input.txt"), 'w') as f: f.write("TEST1+")
            with open(os.path.join(tmp_directory, "test2.input.txt"), 'w') as f: f.write("+TEST2")

            build([MainTask(tmp_dir=tmp_directory)], local_scheduler=True)
            output_of_luigi = open(os.path.join(tmp_directory, "test.output.txt"), 'r').read()
            expected_output = "TEST1++TEST2"

            self.assertEqual(output_of_luigi, expected_output)



class TargetOutputTests(unittest.TestCase):
    def test_target_output1(self):
        """We test TargetOutput as the return of the output() function of a luigi task"""

        class MyMainTask(Task):

            def requires(self):
                return {}

            def run(self):
                x = self.output()
                with x.open('w') as f:
                    f.write("ABC123")

            def output(self):
                return TargetOutput(ext=".csv")(self)

        with tempfile.TemporaryDirectory() as tmp_directory:
            old_dir = os.getcwd()
            os.chdir(tmp_directory)
            try:
                build([MyMainTask()], local_scheduler=True)
                with open(os.path.join(tmp_directory, "MyMainTask.csv")) as f:
                    contents = f.read()
                self.assertEqual(contents, "ABC123")
            finally:
                os.chdir(old_dir)

    def test_target_output2(self):
        """We test TargetOutput as the value of the output variable of a luigi task"""
        class AnotherMainTask(Task):

            def requires(self):
                return {}

            def run(self):
                x = self.output()
                with x.open('w') as f:
                    f.write("TEST2")

            output = TargetOutput()

        with tempfile.TemporaryDirectory() as tmp_directory:
            old_dir = os.getcwd()
            os.chdir(tmp_directory)
            try:
                build([AnotherMainTask()], local_scheduler=True)
                with open(os.path.join(tmp_directory, "AnotherMainTask.txt")) as f:
                    contents = f.read()
                self.assertEqual(contents, "TEST2")
            finally:
                os.chdir(old_dir)


    def test_target_output_with_params(self):
        """We test TargetOutput in a task with parameters, using a custom base dir and extension"""
        class AnotherMainTask(Task):
            region_name:str=Parameter()
            country_code:str=Parameter()

            def requires(self):
                return {}

            def run(self):
                x = self.output()
                with x.open('w') as f:
                    f.write("Welcome to " + self.region_name +',' + self.country_code)

            output = TargetOutput(basedir='./my-basedir', ext='.wlc')


        with tempfile.TemporaryDirectory() as tmp_directory:
            old_dir = os.getcwd()
            os.chdir(tmp_directory)
            try:
                build([AnotherMainTask(region_name="Madrid", country_code="ES")], local_scheduler=True)
                expected_output="Welcome to Madrid,ES"
                with open(os.path.join(tmp_directory, 'my-basedir/AnotherMainTask(country_code=ES,region_name=Madrid).wlc')) as f:
                    luigi_output = f.read()

                self.assertEqual(luigi_output, expected_output)
            finally:
                os.chdir(old_dir)


