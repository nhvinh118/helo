from luigi import LocalTarget, Parameter
import os


class Requirement:
    def __init__(self, task_class, **params):
        self.task_class = task_class
        self.params = params

    def __get__(self, task, cls):
        if task is None:
            return self

        return task.clone(
            self.task_class,
            **self.params)


class Requires:
    """Composition to replace :meth:`luigi.task.Task.requires`

    Example::

        class MyTask(Task):
            # Replace task.requires()
            requires = Requires()
            other = Requirement(OtherTask)

            def run(self):
                # Convenient access here...
                with self.other.output().open('r') as f:
                    ...

        >> MyTask().requires()
        {'other': OtherTask()}

    """

    def __get__(self, task, cls):
        if task is None:
            return self

        # Bind self/task in a closure
        return lambda: self(task)

    def __call__(self, task):
        """Returns the requirements of a task

        Assumes the task class has :class:`.Requirement` descriptors, which
        can clone the appropriate dependencies from the task instance.

        :returns: requirements compatible with `task.requires()`
        :rtype: dict
        """

        return {attrname: getattr(task, attrname) for attrname in dir(task.__class__)
                if isinstance(getattr(task.__class__, attrname), Requirement)}


class TargetOutput:
    def __init__(self, file_pattern='{task.__class__.__name__}{params}', ext='.txt', basedir='.',
                 target_class=LocalTarget, **target_kwargs):

        self.file_pattern = file_pattern
        self.ext = ext
        self.basedir = basedir
        self.target_class = target_class
        self.target_kwargs = target_kwargs

    def __get__(self, task, cls):
        if task is None:
            return self
        return lambda: self(task)

    def __call__(self, task):
        def get_params(task):
            params = ['{}={}'.format(attrname, getattr(task, attrname)) for attrname in dir(task.__class__)
                      if isinstance(getattr(task.__class__, attrname), Parameter)]

            if params:
                return '(' + ','.join(params) + ')'
            else:
                return ''

        path = self.basedir + os.sep + self.file_pattern.format(task=task, params=get_params(task)) + self.ext
        return self.target_class(path=path, **self.target_kwargs)
