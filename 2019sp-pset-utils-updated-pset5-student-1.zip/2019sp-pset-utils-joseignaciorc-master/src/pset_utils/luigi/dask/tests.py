from .target import ParquetTarget, CSVTarget
from unittest import TestCase
import pandas as pd
import tempfile
import os
from os.path import join as j
from luigi import Task, ExternalTask, build
import dask.dataframe


class ParquetTests(TestCase):
    def test_parquet_to_csv(self):
        """A test that read """

        with tempfile.TemporaryDirectory() as tmp_dir:
            pdf: pd.DataFrame = pd.DataFrame([{'col1': 'One', 'col2': 'Two', 'col3': 'Three'},
                                              {'col1': 'Uno', 'col2': 'Dos', 'col3': 'Tres'}])
            ddf: dask.dataframe = dask.dataframe.from_pandas(pdf, npartitions=2)

            ddf.to_parquet(j(tmp_dir, "test_file.parquet"))
            open(j(tmp_dir, "test_file.parquet", "_SUCCESS"), 'w').close()


            class InputParquetTask(ExternalTask):
                def output(self):
                    return ParquetTarget(j(tmp_dir, "test_file.parquet"+os.sep))

            class ToCsvTask(Task):
                def requires(self):
                    return InputParquetTask()

                def output(self):
                    return CSVTarget(j(tmp_dir, "out_file.csv/"))

                def run(self):
                    daskdf = self.input().read_dask()
                    self.output().write_dask(daskdf)

            build([ToCsvTask()], local_scheduler=True)

            with open(j(tmp_dir,"out_file.csv","0.part")) as f:
                contents=f.read()

            self.assertTrue(contents.startswith("index,col1,col2,col3"))


    def test_csv_to_parquet(self):
        with tempfile.TemporaryDirectory() as tmp_dir:

            csv="column1,column2,column3\n" \
                "One,Two,Three\n" \
                "Eins,Zwei,Drei"

            with open(j(tmp_dir,"0.part"),"w") as f:
                f.write(csv)

            class InputCsvTask(ExternalTask):
                def output(self):
                    return CSVTarget(j(tmp_dir+"/"), flag=False, glob="*")

            class ToParquetTask(Task):
                def requires(self):
                    return InputCsvTask()

                def run(self):
                    daskdf = self.input().read_dask()
                    self.output().write_dask(daskdf)

                def output(self):
                    return ParquetTarget(tmp_dir+"/")

            build([ToParquetTask()], local_scheduler=True)

            stored_file=dask.dataframe.read_parquet(tmp_dir).compute().to_dict()
            expected={'column1': {0: 'One', 1: 'Eins'}, 'column2': {0: 'Two', 1: 'Zwei'}, 'column3': {0: 'Three', 1: 'Drei'}}
            self.assertDictEqual(stored_file, expected)
