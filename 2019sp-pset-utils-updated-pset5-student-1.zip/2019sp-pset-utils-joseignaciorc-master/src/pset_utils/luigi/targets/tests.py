from unittest import TestCase
from luigi import Task, ExternalTask, Parameter, LocalTarget, build
import luigi.format
import os
from pset_utils.luigi import targets
import unittest
import tempfile


class SuffixPreservingLocalTargetTests(TestCase):

    def test_suffix_preserving_local_target(self):
        input_data = b"\x00\x01\xff\xe2\x28\xa1" #Data chosen because it is not a valid UTF-8 string
        expected_output=input_data*3

        class MockInput(ExternalTask):
            """A simple task that read a file"""
            tmp_dir:str = Parameter()
            unittest_obj= Parameter()

            def output(self):
                return LocalTarget(os.path.join(self.tmp_dir, "test.input.bin"),format=luigi.format.Nop)


        class ReadAndTriplicateDataUsingSuffixPreservingLocalTarget(Task):
            """ A Luigi task that gets data from MockInput, triplicates it and finally saves it do disk using SuffixPreservingLocalTarget"""
            tmp_dir:str = Parameter()
            unittest_obj:TestCase = Parameter()

            def requires(self):
                return MockInput(self.tmp_dir, self.unittest_obj)

            def output(self):
                return targets.SuffixPreservingLocalTarget(os.path.join(self.tmp_dir, "test.output.bin"), format=luigi.format.Nop)


            def run(self):
                with self.output().temporary_path() as temp_output_path:

                    #We test that the suffix is preserved
                    self.unittest_obj.assertTrue(temp_output_path.endswith("test.output.bin"))
                    with self.input().open('r') as inp_file:
                        inp_contents = inp_file.read()
                    with open(temp_output_path,'wb') as output_file:
                        output_file.write(inp_contents*3)


        with tempfile.TemporaryDirectory() as tmp_dir:

            # First, we create a file with the input_data
            open(os.path.join(tmp_dir,"test.input.bin"),'wb').write(input_data)

            # Then, we run the Luigi Task. This task uses the SuffixPreservingLocalTarget that we want to test
            build([ReadAndTriplicateDataUsingSuffixPreservingLocalTarget(tmp_dir=tmp_dir, unittest_obj=self)],  local_scheduler=True)
            output_of_luigi = open(os.path.join(tmp_dir, "test.output.bin"), 'rb').read()

            # Finally, we assert that the output of luigi and the expected output are the same
            self.assertEqual(output_of_luigi, expected_output)
