import hashlib
import os
import string

def get_csci_salt()->bytes:
    """Returns the appropriate salt for CSCI E-29

    :rtype: bytes
    """

    if 'CSCI_SALT' not in os.environ:
        raise ValueError("CSCI_SALT has not been defined in the environment")

    if not all(c in string.hexdigits for c in os.environ['CSCI_SALT']):
        raise ValueError("CSCI_SALT should be contain only hex digits")

    salt=bytes.fromhex(os.environ['CSCI_SALT'])

    return salt





def hash_str(some_val, salt=''):
    """Converts strings to hash digest

    See: https://en.wikipedia.org/wiki/Salt_(cryptography)

    :param str or bytes some_val: thing to hash

    :param str or bytes salt: string or bytes to add randomness to the hashing,
        defaults to ''.

    :rtype: bytes
    """

    if isinstance(some_val, str):
        some_val = some_val.encode()
    elif isinstance(some_val, bytes):
        pass
    else:
        raise TypeError("some_val must be str or bytes")


    if type(salt) is str:
        salt=salt.encode()
    elif type(salt) is bytes:
        pass
    else:
        raise TypeError("Salt must be str or bytes")




    return hashlib.sha256(salt+some_val).digest()



def get_user_id(username:str)->str:
    """
    :param username: the username to hash (using the default salt)
    :return: the hashed username
    """
    salt = get_csci_salt()
    return hash_str(username.lower(), salt=salt).hex()[:8]
