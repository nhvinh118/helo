#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `pset_1` package."""

import os
from tempfile import TemporaryDirectory, NamedTemporaryFile
from unittest import TestCase, mock

from ..hashing import hash_str,get_user_id

import hashlib


class HashTests(TestCase):

    def test_basic(self):
        self.assertEqual(
            hash_str('world!', salt='hello, ').hex()[:6], '68e656')


    # We use mock, as seen in the post by Javid Lakha <https://piazza.com/class/jqhidqternh3sq?cid=216>
    @mock.patch.dict(os.environ,{'CSCI_SALT':'abcd'})
    def test_get_user_id(self):
        self.assertEqual(
            get_user_id("joseignaciorc"),
            hashlib.sha256(b'\xab'+ b'\xcd'+"joseignaciorc".encode()).hexdigest()[:8])
