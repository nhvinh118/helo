========
Overview
========

.. start-badges

.. list-table::
    :stub-columns: 1


    * - tests
      - | |travis|
        |


.. |travis| image:: https://travis-ci.com/csci-e-29/2019sp-pset-utils-joseignaciorc.svg?token=SZyzUVosspEDL61LxXDH&branch=master
    :target: https://travis-ci.com/csci-e-29/2019sp-pset-utils-joseignaciorcttps://travis-ci.org/csci-e-29/2019sp-pset-utils-joseignaciorc




.. end-badges

Common utilities for psets

* Free software: BSD 2-Clause License

Installation
============

::

    pip install pset-utils


Development
===========

To run the all tests run::

    tox

Note, to combine the coverage data from all the tox environments run:

.. list-table::
    :widths: 10 90
    :stub-columns: 1

    - - Windows
      - ::

            set PYTEST_ADDOPTS=--cov-append
            tox

    - - Other
      - ::

            PYTEST_ADDOPTS=--cov-append tox
