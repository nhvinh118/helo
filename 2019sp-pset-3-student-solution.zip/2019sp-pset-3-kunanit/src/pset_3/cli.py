"""
Module that contains the command line app.

Why does this file exist, and why not put this in __main__?

    You might be tempted to import things from __main__ later, but that will cause
    problems: the code will get executed twice:

    - When you run `python -mpset_3` python will execute
        ``__main__.py`` as a script. That means there won't be any
        ``pset_3.__main__`` in ``sys.modules``.
    - When you import __main__ it will get executed again (as a module) because
      there's no ``pset_3.__main__`` in ``sys.modules``.

    Also see (1) from http://click.pocoo.org/5/setuptools/#setuptools-integration
"""
import os
import pandas as pd
from pset_utils.io import atomic_write  # import may look different depending on pset utils package structure
from .data import load_data
from .embedding import WordEmbedding, cosine_similarity


def main(words_file, vectors_file, data_file, distance_file, reference_hash):
    """Calculates word embeddings of student project text documents, then finds
    the "nearest" students to a reference student based on a distance metric
    (1 - cosine difference). Caches the results of the distance calculation, and
    uses the cache if available to generate output.

    Fine to hardcode data file relative paths here, but having them as arguments
    makes this more reusable and testable

    :param words_file: filename of word list text file (data/words.txt)
    :type words_file: str
    :param vectors_file: filename of embedding matrix numpy file (data/vectors.npy.gz)
    :type vectors_file: str
    :param data_file: filename student text parquet file (data/hashed.parquet)
    :type data_file: str
    :param distance_file: filename of distance parquet file to generate/read (data/distance_to_ta.parquet)
    :type distance_file: str
    """

    # instantiate WordEmbedding instance from files
    embedding = WordEmbedding.from_files(words_file, vectors_file)

    # file with project text hashed by 
    data = load_data(data_file)

    # Generate distance data file if it does not already exist
    if not os.path.isfile(distance_file):
        # create the vector representation for each survey entry
        # embeddings is a Series of distance values indexed by student hashed id
        embeddings = data.project.apply(embedding.embed_document)

        # TA vector to compute distances relative to
        reference_vector = embeddings[reference_hash]

        # calculate distance relative to TA vector
        distance = 1-embeddings.apply(cosine_similarity, args=(reference_vector,))
        
        # write to file
        with atomic_write(distance_file, as_file=False) as f:
            # convert to dataframe so we can use the df.to_parquet writer method
            distance.to_frame(name='distance').to_parquet(f)
    else:
        print(f"Distance already computed; using cached file: {distance_file}")
    
    # load data from distance file
    distance = pd.read_parquet(distance_file)
    # join distance to project data, sort and select
    five_friends = data.join(distance).nsmallest(5, 'distance')
    # print output
    print(five_friends)

    # return hash id of nearest student for testing
    return five_friends.iloc[1].name
