import re
import numpy as np
from .data import load_words, load_vectors


class WordEmbedding(object):
    def __init__(self, words, vecs):
        """
        :param words: vocabulary of word tokens, as a list with length <vocab_length>
        :type words: list
        :param vecs: 2D matrix of word embedding vectors, with shape (vocab_length,dim_embedding)
        :type vecs: np.ndarray
        """
        # mapping from words to respective embedding vectors
        self.word_vectors = dict(zip(words, vecs))

        # dimension of embedding vectors
        self.dim_embedding = vecs.shape[1]

    def __call__(self, word):
        """Embed a word

        :returns: vector embedding, or None if the word is outside of the vocabulary
        :rtype: ndarray
        """
        # get operation on dictionary is average O(1)
        return self.word_vectors.get(word)

    @classmethod
    def from_files(cls, word_file, vec_file):
        """Instantiate an embedding from files

        Example::

            embedding = WordEmbedding.from_files('words.txt', 'vecs.npy.gz')

        :rtype: cls
        """
        return cls(load_words(word_file), load_vectors(vec_file))

    def tokenize(self, text):
        """Extract word tokens from document text
        
        :param text: document text, e.g. sentence
        :type text: str
        :return: list of words
        :rtype: list
        """
        # Get all "words", including contractions
        # eg tokenize("Hello, I'm Scott") --> ['hello', "i'm", 'scott']
        return re.findall(r"\w[\w']+", text.lower())

    def embed_document(self, text):
        """Convert text to vector, by finding vectors for each word and combining

        :param str document: the document (one or more words) to get a vector
            representation for

        :return: vector representation of document
        :rtype: ndarray
        """
        # iterator over non-zero embedding vectors
        # Assume any words not in the vocabulary are treated as 0's
        vectors = filter(lambda x: x is not None, map(self, self.tokenize(text)))

        # sum() over an iterator is memory efficient
        # Returns a zero vector even if no words in the document are part of the vocabulary
        return sum(vectors, np.zeros(self.dim_embedding))


def cosine_similarity(a, b):
    """Compute cosine similarity between two vectors
    Returns np.nan if zero vector is used as input
    
    :param ndarray a: vector
    :param ndarray b: vector
    """
    magnitude = np.linalg.norm(a) * np.linalg.norm(b)
    if magnitude == 0:
        return np.nan
    return np.dot(a,b) / magnitude
