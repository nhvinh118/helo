"""
Entrypoint module, in case you use `python -mpset_3`.


Why does this file exist, and why __main__? For more info, read:

- https://www.python.org/dev/peps/pep-0338/
- https://docs.python.org/2/using/cmdline.html#cmdoption-m
- https://docs.python.org/3/using/cmdline.html#cmdoption-m
"""
from pset_3.cli import main

if __name__ == "__main__":
    main(
        words_file = 'data/words.txt',
        vectors_file = 'data/vectors.npy.gz',
        data_file = 'data/hashed.parquet',
        distance_file = 'data/distance_to_ta.parquet',
        reference_hash = '33a0b58b'
    )
