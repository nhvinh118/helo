import os
from unittest import TestCase
import tempfile
import numpy as np
import pandas as pd
from pset_3.cli import main
from pset_3.data import load_data, load_words, load_vectors
from pset_3.embedding import WordEmbedding, cosine_similarity


# define test data

TEST_WORDS = ['hello',"i'm",'scott']  # vocab
np.random.seed(1)  # set seed so np.random.rand() is deterministic
TEST_VECS = np.random.rand(len(TEST_WORDS), 10)  # embedding matrix
# student text data
TEST_DATA = pd.DataFrame(
    {'project':['printing hello world', "printing hello i'm scott", '']},
    index=pd.Index(['abcd1111','abcd2222', 'abcd3333'],name='hashed_id')
)


def temp_words_file(words):
    """Generate temporary words file
    
    :param list words: list of words to write to file

    :return: temporary word list file object
    :rtype: NamedTemporaryFile
    """
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as words_file:
        words_file.writelines(word+'\n' for word in words)
    return words_file


def temp_vecs_file(vecs):
    """Generate temporary embedding matrix file
    
    :param ndarray vecs: embedding matrix

    :return: temporary embedding matrix file object
    :rtype: NamedTemporaryFile
    """
    with tempfile.NamedTemporaryFile(delete=False) as vectors_file:
        np.save(vectors_file, vecs)
    return vectors_file


def temp_data_file(data):
    """Generate temporary student text file
    
    :param DataFrame data: student project text data, indexed by hashed id
    
    :return: temporary student text file object
    :rtype: NamedTemporaryFile
    """
    with tempfile.NamedTemporaryFile(delete=False) as data_file:
        data.to_parquet(data_file)
    return data_file

# unit tests

class DataTests(TestCase):
    def setUp(self):
        self.words = TEST_WORDS
        self.vecs = TEST_VECS
        self.data = TEST_DATA
        self.words_file = temp_words_file(self.words)
        self.vectors_file = temp_vecs_file(self.vecs)
        self.data_file = temp_data_file(self.data)
        
    def tearDown(self):
        """Remove temporary files after testing"""
        self.words_file.close()
        self.vectors_file.close()
        self.data_file.close()

    def test_load_words(self):
        """load_words() loads file as a list of words with correct content"""
        words = load_words(self.words_file.name)
        self.assertTrue(isinstance(words, list))
        self.assertEqual(words, self.words)

    def test_load_vectors(self):
        """load_vectors() loads file as a numpy matrix with correct content"""
        vecs = load_vectors(self.vectors_file.name)
        self.assertTrue(isinstance(vecs, np.ndarray))
        self.assertTrue(np.array_equal(vecs, self.vecs))

    def test_load_data(self):
        """load_data() loads file as a pandas dataframe with correct content"""
        data = load_data(self.data_file.name)
        self.assertTrue(isinstance(data, pd.DataFrame))
        self.assertTrue(data.equals(self.data))


class EmbeddingTests(TestCase):
    def setUp(self):
        self.words = TEST_WORDS
        self.vecs = TEST_VECS
        self.data = TEST_DATA
        self.word_vectors = dict(zip(self.words, self.vecs))
        # WordEmbedding instance to test
        self.embedding = WordEmbedding(self.words, self.vecs)
    
    def test_call(self):
        """
        Embedding vector for word matches vector from input
        """
        word_vector = self.vecs[self.words.index('hello')]  # expected vector
        self.assertTrue(np.array_equal(
            self.embedding('hello'),
            word_vector 
        ))

    def test_call_oov(self):
        """embedding(word) returns None if word not in vocab"""
        assert 'goodbye' not in self.words
        self.assertTrue(self.embedding('goodbye') is None)

    def tokenize(self):
        """tokenize("Hello, I'm Scott") --> ['hello', "i'm", 'scott']"""
        self.assertTrue(self.embedding.tokenize("Hello, I'm Scott"))

    def test_embed_document(self):
        """Document embedding for test documents match expected document vector values"""
        self.assertTrue(np.array_equal(
            self.embedding.embed_document('printing hello world'),
            self.word_vectors['hello']  # sum of vectors corresponding to words in vocab
        ))
        self.assertTrue(np.array_equal(
            self.embedding.embed_document("printing hello i'm scott"),
            # sum of vectors corresponding to words in vocab
            self.word_vectors['hello'] + self.word_vectors["i'm"] + self.word_vectors['scott']
        ))
    
    def test_embed_document_empty(self):
        """Embedding of an empty document is a vector of zeros"""
        self.assertTrue(np.array_equal(
            self.embedding.embed_document(''),
            np.zeros(self.vecs.shape[1])  # zero vector
        ))


class CosineSimilarityTests(TestCase):
    def setUp(self):
        self.a = np.array([1, 0, 0])
        self.b = np.array([0, 2, 0])  # orthogonal to a

    def test_cosine_similarity_same_vecs(self):
        """Cosine similiarity for identical vectors equals 1"""
        self.assertAlmostEqual(cosine_similarity(self.a, self.a), 1)

    def test_cosine_similarity_orth_vecs(self):
        """Cosine similarity for orthogonal vectors equals 0"""
        self.assertAlmostEqual(cosine_similarity(self.a, self.b), 0)

    def test_cosine_similarity_zero_vec(self):
        """Cosine similarity with zero vector input returns np.nan"""
        self.assertTrue(np.isnan(cosine_similarity(np.zeros(len(self.a)), self.a)))

# integration test

class MainTests(TestCase):
    def setUp(self):
        self.words = TEST_WORDS
        self.vecs = TEST_VECS
        self.data = TEST_DATA
        # set up data files for initializing embedding
        self.words_file = temp_words_file(self.words)
        self.vectors_file = temp_vecs_file(self.vecs)
        self.data_file = temp_data_file(self.data)
        # create temporary directory for distance file output
        self.tmpdir = tempfile.TemporaryDirectory()
        self.distance_file = os.path.join(self.tmpdir.name,'distance_to_ta.parquet')

    def tearDown(self):
        # clean up temp resources
        self.words_file.close()
        self.vectors_file.close()
        self.data_file.close()
        self.tmpdir.cleanup()
        
    def test_main(self):
        """Main function executes and returns expected nearest student"""
        nearest_hash_id = main(
            words_file = self.words_file.name,
            vectors_file = self.vectors_file.name,
            data_file = self.data_file.name,
            distance_file = self.distance_file,
            reference_hash = 'abcd1111'
        )
        self.assertEqual(nearest_hash_id, 'abcd2222')
