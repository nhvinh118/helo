
Changelog
=========

0.0.0 (2019-04-01)
------------------

* First release on PyPI.
