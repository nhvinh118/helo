# Pset 3

[![Build Status](https://travis-ci.com/csci-e-29/2019sp-pset-3-kunanit.svg?token=PqpdKLQzDuDjxLDNsupq&branch=master)](https://travis-ci.com/csci-e-29/2019sp-pset-3-kunanit)

Customizing our own cookiecutter repo, and using it to complete a Word2Vec
project.

Note: This problem set will involve submitting two separate repos:

(1) customized cookiecutter  
(2) pset 3  

Please submit both links to the Canvas assignments when you have completed!

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
**Table of Contents**  *generated with [DocToc](https://github.com/thlorenz/doctoc)*

- [Preface](#preface)
  - [Atomicity and utils](#atomicity-and-utils)
- [Problems (45 points)](#problems-45-points)
  - [Use your cookiecutter to create your pset-3 repo (10 points)](#use-your-cookiecutter-to-create-your-pset-3-repo-10-points)
    - [Push your pset 3 repo](#push-your-pset-3-repo)
  - [Student Embeddings (35 points)](#student-embeddings-35-points)
    - [AWS Data](#aws-data)
    - [Loading the data (5 points)](#loading-the-data-5-points)
    - [Embedding (10 points)](#embedding-10-points)
    - [Cosine similarity (5 points)](#cosine-similarity-5-points)
    - [Find the TA's friend (5 points)](#find-the-tas-friend-5-points)
    - [An 'atomic' workflow (5 points)](#an-atomic-workflow-5-points)
    - [Join and output (5 points)](#join-and-output-5-points)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

## Preface

**DO NOT CLONE THIS REPO LOCALLY YET**.  We will manually create a repo and link
it.  If you have cloned this repo locally, simply delete
it (it's fine if it's already forked on github).

### Atomicity and utils

You'll be using your `atomic_write` function in this problem set. After you
initiate the repo, `pipenv install` your `pset_utils` repo as instructed
previously. Let us know if you have issues here as this involves a bit more
configuration than ideal.  You can add the atomic write later if you are
blocked.

## Problems (45 points)

### Use your cookiecutter to create your pset-3 repo (10 points)

In the directory above `2019sp-cookiecutter-csci-pset-YOUR_GITHUB_ID`, *do the following*:

```bash
cookiecutter 2019sp-cookiecutter-csci-pset-YOUR_GITHUB_ID/
```

You have configured many things already such as name, github id, travis, etc.

In addition, for this project specifically, make sure to *do the following*:  

| Param | Value |  
|-|-|  
| project_name | `Pset 3` |  
| repo_name | (should default to `2019sp-pset-3-YOUR_GITHUB_ID`) |  
| package_name | (should default to `pset_3`) |  

#### Push your pset 3 repo

Now you can *push to your pset 3 repo* via:

```bash
cd 2019sp-pset-3-<YOUR_GITHUB_ID>
git init
git add --all  # though nicer if you do this manually/via SourceTree
git commit -m "Add initial project skeleton."
git remote add origin git@github.com:csci-e-29/2019sp-pset-3-YOUR_GITHUB_ID.git
git fetch
git merge origin/master --allow-unrelated-histories
git push -u origin master
```

### Student Embeddings (35 points)

#### AWS Data

Navigate into your pset 3 directory in terminal. You should be able to copy the
data locally via:

```bash
aws s3 cp s3://cscie29-data/embeddings/ data/ --recursive
```

and add that line into your travis file in the answer stage, similar to how
it was in pset 1 (it should only run on your master branch!).

You should now have a new folder called `data` with three files we'll use for
this problem set.

For these problems, we will use the three files you pulled from S3:

1. `data/words.txt` contains  a list of 9844 common words.

2. `data/vectors.npy.gz` is a 9844x300 embedding matrix. Each row of the matrix
is the 300-dimensional vector representation for the word at the same position in
the vocab list (first row <-> first word in list, ... etc).  You can load this
with `numpy.load`.

3. `data/hashed.parquet`, a dataframe containing hashed github user ids, and
answers from pset 0 about a python project you have completed.


#### Loading the data (5 points)

You will need to write functions to load the three datasets; please implement
them in `pset_3.data`

You likely already have or need `awscli`, `pandas`, and `pyarrow` in your
Pipfile. You will likely also need `numpy`. As a reminder, you should install
such packages via `pipenv install numpy`.

```python
def load_words(filename):
    """Load a file containing a list of words as a python list

    use case: data/words.txt

    :param str filename: path/name to file to load
    :rtype: list
    """
    ...

def load_vectors(filename):
    """Loads a file containing word vectors to a python numpy array

    use case: `data/vectors.npy.gz`
    :param str filename:

    :returns: 2D matrix with shape (m, n) where m is number of words in vocab
        and n is the dimension of the embedding

    :rtype: ndarray
    """
    ...

def load_data(filename):
    """Load student response data in parquet format

    use case: data/hashed.parquet
    :param str filename:

    :returns: dataframe indexed on a hashed github id
    :rtype: DataFrame
    """
    # You will probably need to fill a few NA's and set/sort the index via
    # pandas
    ...

```

#### Embedding (10 points)

***Create a class*** called `WordEmbedding`, which is initialized with two
arguments: the word list and the vectors.  Implement the embedding as the
`__call__` method as well as a helper constructor to load from files (we do
this to help with testing).

You can implement this in `pset_3.embedding`:

```python
class WordEmbedding(object):
    def __init__(self, words, vecs):
        ...

    def __call__(self, word):
        """Embed a word

        :returns: vector, or None if the word is outside of the vocabulary
        :rtype: ndarray
        """

        # Consider how you implement the vocab lookup.  It should be O(1).
        ...

    @classmethod
    def from_files(cls, word_file, vec_file):
        """Instantiate an embedding from files

        Example::

            embedding = WordEmbedding.from_files('words.txt', 'vecs.npy.gz')

        :rtype: cls
        """
        return cls(load_words(word_file), load_vectors(vec_file))
```

Finally, we need a way to combine embeddings for multiple words into a 'document
embedding', aka a single vector for an entire body of text.  

***Add a function*** (`embed_document`) that embeds documents using the simple
approach of just adding the vectors. Note that you will need to use the
`tokenize` function provided in order to get all "words" of a document.

```python
import re

class WordEmbedding(object):
    ...

    def tokenize(self, text):
        # Get all "words", including contractions
        # eg tokenize("Hello, I'm Scott") --> ['hello', "i'm", 'scott']
        return re.findall(r"\w[\w']+", text.lower())

    def embed_document(self, text):
        """Convert text to vector, by finding vectors for each word and combining

        :param str document: the document (one or more words) to get a vector
            representation for

        :return: vector representation of document
        :rtype: ndarray (1D)
        """
            # Use tokenize(), maybe map(), functools.reduce, itertools.aggregate...
            # Assume any words not in the vocabulary are treated as 0's
            # Return a zero vector even if no words in the document are part
            # of the vocabulary
            ...
```

To wrap it all up, you can use [Pandas
apply](http://pandas.pydata.org/pandas-docs/stable/generated/pandas.Series.apply.html?highlight=apply#pandas.Series.apply)
to execute your code in a functional way.

Add something along these lines to `pset_3.cli` to execute everything
you've done so far.

```python
def main(args=None):
    embedding = WordEmbedding.from_files('data/words.txt', 'data/vectors.npy.gz')

    # read in the hashed student data
    data = load_data('data/hashed.parquet')

    # create the vector representation for each survey entry
    # Note: this result will be a Series object preserving the index with vectors inside
    embeddings = data['project'].apply(embedding.embed_document)
```

#### Cosine similarity (5 points)

Since words are being represented as vectors, we can compute a distance metric
to represent how "similar" two words are. There are a couple of distance metrics
we can use - [cosine
similarity](https://en.wikipedia.org/wiki/Cosine_similarity) is a commonly used
one. Cosine similarity is defined as:

![](https://latex.codecogs.com/svg.latex?similarity%28A%2C%20B%29%20%3D%20cos%28%5Ctheta%29%20%3D%20%5Cfrac%20%7BA%20%5Ccdot%20B%7D%20%7B%5Cleft%5C%7C%20A%20%5Cright%5C%7C%20%5Cleft%5C%7C%20B%20%5Cright%5C%7C%20%7D%20%3D%20%5Cfrac%20%7B%5Csum%20A_i%20B_i%7D%20%7B%20%5Csqrt%7B%5Csum%20A_i%5E2%7D%20%5Csqrt%7B%5Csum%20B_i%5E2%7D%20%7D)

***Implement a function*** `cosine_similarity(a, b)` that computes cosine
similarity for two vector inputs. Be sure to test it. Please use `numpy.dot`
and `numpy.linalg.norm` in your implementation.

Note: We did not provide starter code! Time to take control, it's your
application after all. Don't overthink it - it should just be a short snippet.
Create a home for the cosine function that makes sense and be sure to include a
doc string describing what it does.


#### Find the TA's friend (5 points)

One of the TAs took this class last semester and responded to this survey. Their
survey result corresponds to the hashed github ID `33a0b58b` in the
`hashed.parquet` file.

***Calculate the distance*** between the TA's response and those of current
students using your cosine similarity method.  Note that `distance(x,y) == 1 -
cosine_similarity(x, y)`.

Persist this output as a new parquet file.

```python
def main(args=None):
    ...

    distance = ... # series or data frame

    # utilize atomic_write to export results to data/embedded.csv
    filename = "data/distance_to_ta.parquet"

    # Ensure you are ***only*** writing the index and distance!
    distance.to_parquet(f)
```

#### An 'atomic' workflow (5 points)

Go back and restructure your `main()` method to ***only calculate the distance
if the output file does not exist***.  If the file exists when the program
starts, assume it has already been calculated correctly (you can delete it
if you need to rerun!).  Be sure to also use your `atomic_write` function.

#### Join and output (5 points)

After writing the distance if it doesn't already exist, read it back and print a
summary of the top five most similar students, including the TA.  The summary
should include the id, the distance, and the project text in some human readable
form.

```python
def main(args=None):
    ...
    distance = ... # load back from disk
    five_friends = ... # join distance to project data, sort and select

    for friend, row in five_friends.iterrows():
        # Print out a summary of the TA and the 4 closest students
        ...
```

Answer in Canvas:
***What is the hashed ID of the most similar student to this TA?***
