=====
Usage
=====

To use Pset 3 in a project::

	import pset_3
