pset_3
======

.. testsetup::

    from pset_3 import *

.. automodule:: pset_3
    :members:
