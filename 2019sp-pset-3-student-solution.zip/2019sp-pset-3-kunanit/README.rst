========
Overview
========

.. start-badges

.. list-table::
    :stub-columns: 1

    * - docs
      - |docs|
    * - tests
      - | |travis| |appveyor|
        |
    * - package
      - | |version| |wheel| |supported-versions| |supported-implementations|
        | |commits-since|
.. |docs| image:: https://readthedocs.org/projects/2019sp-pset-3-kunanit/badge/?style=flat
    :target: https://readthedocs.org/projects/2019sp-pset-3-kunanit
    :alt: Documentation Status

.. |travis| image:: https://travis-ci.org/csci-e-29/2019sp-pset-3-kunanit.svg?branch=master
    :alt: Travis-CI Build Status
    :target: https://travis-ci.org/csci-e-29/2019sp-pset-3-kunanit

.. |appveyor| image:: https://ci.appveyor.com/api/projects/status/github/csci-e-29/2019sp-pset-3-kunanit?branch=master&svg=true
    :alt: AppVeyor Build Status
    :target: https://ci.appveyor.com/project/csci-e-29/2019sp-pset-3-kunanit

.. |version| image:: https://img.shields.io/pypi/v/pset-3.svg
    :alt: PyPI Package latest release
    :target: https://pypi.org/project/pset-3

.. |commits-since| image:: https://img.shields.io/github/commits-since/csci-e-29/2019sp-pset-3-kunanit/v0.0.0.svg
    :alt: Commits since latest release
    :target: https://github.com/csci-e-29/2019sp-pset-3-kunanit/compare/v0.0.0...master

.. |wheel| image:: https://img.shields.io/pypi/wheel/pset-3.svg
    :alt: PyPI Wheel
    :target: https://pypi.org/project/pset-3

.. |supported-versions| image:: https://img.shields.io/pypi/pyversions/pset-3.svg
    :alt: Supported versions
    :target: https://pypi.org/project/pset-3

.. |supported-implementations| image:: https://img.shields.io/pypi/implementation/pset-3.svg
    :alt: Supported implementations
    :target: https://pypi.org/project/pset-3


.. end-badges

csci-e-29 pset 3

* Free software: BSD 2-Clause License

Installation
============

::

    pip install pset-3

Documentation
=============


https://2019sp-pset-3-kunanit.readthedocs.io/


Development
===========

To run the all tests run::

    tox

Note, to combine the coverage data from all the tox environments run:

.. list-table::
    :widths: 10 90
    :stub-columns: 1

    - - Windows
      - ::

            set PYTEST_ADDOPTS=--cov-append
            tox

    - - Other
      - ::

            PYTEST_ADDOPTS=--cov-append tox
