#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `pset_1` package."""

import os
from tempfile import TemporaryDirectory, NamedTemporaryFile
from unittest import TestCase, main, mock

from pset_1.hash_str import hash_str, get_csci_salt
from pset_1.io import atomic_write


class FakeFileFailure(IOError):
    pass


class HashTests(TestCase):

    def test_basic(self):
        """Ensure hash_str works on two string inputs"""
        self.assertEqual(
            hash_str('world!', salt='hello, ').hex()[:6], '68e656')

    def test_byte_input(self):
        """Ensure hash_str works with byte inputs"""
        self.assertEqual(
            hash_str(b'dsafdsa', salt=b'\x56sdf').hex()[:6], '53520a')

    @mock.patch.dict(os.environ, {'CSCI_SALT': '0123bf'})
    def test_ensure_salt(self):
        try:
            get_csci_salt()
        except KeyError:
            self.fail('CSCI_SALT environment variable not set!')


class AtomicWriteTests(TestCase):

    def test_atomic_write(self):
        """Ensure file exists after being written successfully"""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            with atomic_write(fp, 'w') as f:
                assert not os.path.exists(fp)
                tmpfile = f.name
                f.write('asdf')

            assert not os.path.exists(tmpfile)
            assert os.path.exists(fp)

            with open(fp) as f:
                self.assertEqual(f.read(), 'asdf')

    def test_atomic_failure(self):
        """Ensure that file does not exist after failure during write"""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            with self.assertRaises(FakeFileFailure):
                with atomic_write(fp, 'w') as f:
                    tmpfile = f.name
                    assert os.path.exists(tmpfile)
                    raise FakeFileFailure()

            assert not os.path.exists(tmpfile)
            assert not os.path.exists(fp)

    def test_file_exists_error(self):
        """Ensure an error is raised when a file exists"""
        tempf = NamedTemporaryFile(mode='w')

        with self.assertRaises(FileExistsError):
            with atomic_write(tempf .name):
                pass

        tempf.close()

    def test_suffix(self):
        """Ensure temp file has the same suffix as the requested file"""
        filename = 'clever_unique_name.parquet'

        with atomic_write(filename, as_file=False) as af:
            self.assertEqual(os.path.splitext(filename)[1],
                             os.path.splitext(af)[1])

    def test_write_return_name(self):
        """Test to ensure creating files with the as_file flag set to false
        correctly allows files to be recreated and filled out and removed properly."""
        filename = 'clever_unique_name.file'

        with atomic_write(filename, as_file=False) as af:
            self.assertNotEqual(af, filename)
            with open(af, 'w') as f:
                f.write('junk')
            self.assertTrue(os.path.exists(af))
            self.assertFalse(os.path.exists(filename))

        self.assertFalse(os.path.exists(af))
        self.assertTrue(os.path.exists(filename))
        os.remove(filename)


if __name__ == '__main__':
    main()
