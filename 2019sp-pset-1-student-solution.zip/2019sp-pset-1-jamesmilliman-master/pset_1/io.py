from contextlib import contextmanager

import tempfile
import os


@contextmanager
def atomic_write(file, mode='w', as_file=True, **kwargs):
    """Write a file atomically

    :param file: str or :class:`os.PathLike` target to write

    :param mode: Mode flags for atomic file

    :param bool as_file:  if True, the yielded object is a :class:File.
        (eg, what you get with `open(...)`).  Otherwise, it will be the
        temporary file path string

    :param kwargs: anything else needed to open the file

    :raises: FileExistsError if target exists

    Example::

        with atomic_write("hello.txt") as f:
            f.write("world!")

    """
    if os.path.exists(file):
        raise FileExistsError

    f = tempfile.NamedTemporaryFile(mode=mode, dir=os.getcwd(),
                                    suffix=os.path.splitext(file)[1])

    if as_file:
        try:
            yield f
            os.link(f.name, file)
        finally:
            f.close()
    else:
        filename = f.name
        f.close()
        try:
            yield filename
            os.link(filename, file)
            os.remove(filename)
        except FileNotFoundError:
            # File not created by user
            pass
        finally:
            pass


'''Leaving this around because I think it works on linux and is
beautiful compared to above'''


@contextmanager
def atomic_write_linux_maybe(file, mode='w', as_file=True, **kwargs):
    """Write a file atomically

    :param file: str or :class:`os.PathLike` target to write

    :param mode: Mode flags for atomic file

    :param bool as_file:  if True, the yielded object is a :class:File.
        (eg, what you get with `open(...)`).  Otherwise, it will be the
        temporary file path string

    :param kwargs: anything else needed to open the file

    :raises: FileExistsError if target exists

    Example::

        with atomic_write("hello.txt") as f:
            f.write("world!")

    """
    if os.path.exists(file):
        raise FileExistsError

    f = tempfile.NamedTemporaryFile(mode=mode, dir=os.getcwd(),
                                    suffix=os.path.splitext(file)[1])
    try:
        yield f if as_file else f.name
        os.link(f.name, file)
    finally:
        f.close()