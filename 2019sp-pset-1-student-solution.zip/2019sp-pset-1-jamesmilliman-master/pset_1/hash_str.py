from hashlib import sha256
import os


def get_csci_salt():
    """Returns the appropriate salt for CSCI E-29

    :rtype: bytes
    """
    return bytes.fromhex(os.environ['CSCI_SALT'])


def hash_str(some_val, salt=''):
    """Converts strings to hash digest

    See: https://en.wikipedia.org/wiki/Salt_(cryptography)

    :param str or bytes some_val: thing to hash

    :param str or bytes salt: string or bytes to add randomness to the hashing,
        defaults to ''.

    :rtype: bytes
    """
    if type(some_val) is str:
        some_val = some_val.encode()

    if type(salt) is str:
        salt = salt.encode()

    hasher = sha256()
    hasher.update(salt)
    hasher.update(some_val)
    return hasher.digest()


def get_user_id(username):
    """Hashes username using private salt.

    :param str or bytes username: username input to hash

    :return: digested hash of username
    """
    return hash_str(username.lower(), salt=get_csci_salt()).hex()[:8]
