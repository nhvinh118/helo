from .hash_str import get_csci_salt, get_user_id, hash_str
from .io import atomic_write

import os
import pandas as pd


def get_user_hash(username, salt=None):
    salt = salt or get_csci_salt()  # whoa I just learned something new
    return hash_str(username, salt=salt)


if __name__ == '__main__':

    for user in ['gorlins', 'jamesmilliman']:
        print("Id for {}: {}".format(user, get_user_id(user)))

    data_source = 'data/hashed.xlsx'
    parquet_file = data_source + '.parquet'
    df = pd.read_excel(data_source, index_col=0)

    if os.path.exists(parquet_file):
        os.remove(parquet_file)

    with atomic_write(parquet_file, mode='wb', as_file=False) as fname:
        df.to_parquet(fname)

    dfp = pd.read_parquet(parquet_file, columns=['hashed_id'])
    print(dfp)
