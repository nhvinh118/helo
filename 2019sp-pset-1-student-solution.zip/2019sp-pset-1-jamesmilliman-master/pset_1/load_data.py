
def load_words(filename):
    """Load a file containing a list of words as a python list

    :param str filename: path/name to file to load, file should have one line per word
    :rtype: list

    :raises: FileNotFoundError if filename does not exist
    """

def load_vectors(filename):
    """Loads a file containing word vectors to a python numpy array

    :param filename: path/name to .npy file

    :returns: 2D matrix with shape (m, n) where m is number of words in vocab
        and n is the dimension of the embedding
    :rtype: ndarray

    :raises: FileNotFoundError if filename does not exist
    """

def load_data(filename):
    """Load student response data

    :param str filename: path/name to .xlsx file, first column should be the hashed github id

    :returns: dataframe indexed on a hashed github id, empty cells with be filled with NaN
    :rtype: DataFrame

    :raises: FileNotFoundError if filename does not exist
    """
