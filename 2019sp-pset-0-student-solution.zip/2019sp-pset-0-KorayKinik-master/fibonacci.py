#!/usr/bin/env python3


def last_8(some_int):
    """Return the last 8 digits of an int
    :param int some_int: the number
    :rtype: int
    """
    try: 
        return some_int % 100000000
    except:
        raise AttributeError('error')


def optimized_fibonacci(f):
    x, y = 0, 1
    for i in range(f):
        x, y = y, x+y
    return x   



class SummableSequence(object):

    def __init__(self, n, initial):
        if len(initial) != n:
            raise AttributeError('n must be equal to the number of the first numbers!')
        else:
            self.n = n
            self.initial = initial

    def __call__(self, i):
        t = self.initial
        for j in range(i):
            t = t[1:] + (sum(t), )

        return t[0] 



if __name__ == '__main__':

    print('f(100000)[-8:]', last_8(optimized_fibonacci(100000)))

    new_seq = SummableSequence(3, (5, 7, 11))

    print('new_seq(100000)[-8:]:', last_8(new_seq(100000)))
