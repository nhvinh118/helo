#!/usr/bin/env python3
from functools import reduce

def last_8(some_int):
    """Return the last 8 digits of an int
    :param int some_int: the number
    :rtype: int
    Example:
        last_8(123456789)
        23456789
    """
    last_no_digits = 8 # Set default to 8
    return abs(some_int) % (10**last_no_digits)

def recursive_fibonacci(f):
    """Implementation of Fibonacci sequence using the recursive approach
    This implementation is memory inefficient and only works for very snall number
    :param int f: the ith non-zero number
    :rtype: int
    Example:
        recursive_fibonacci(6)
        6
    """
    if f == 0:
       return 0
    if f == 1:
       return 1
    if f<= 10:
        return(recursive_fibonacci(f-1)+recursive_fibonacci(f-2))
    else:
        print(f, " is greater than 10 (the limit of this function)")
        return 0

def optimized_fibonacci(f):
    """Optimized implementation of Fibonacci sequence
    This implementation is memory efficient and can works for large number
    Improvement is made by:
    (1) replacing 'recursive' with 'while' loop and
    (2) using python in-place swap
    :param int f: the ith non-zero number
    :rtype: int the sum (i-1)+(i-2)
    Example:
        optimized_fibonacci(0)
        0
        optimized_fibonacci(1)
        1
        optimized_fibonacci(6)
        8
        optimized_fibonacci(10000)
        10946
    """
    a, b = 0, 1
    if f <= 0:
        return 0
    for i in range(f):
        a, b = b, a + b
    return a   


class SummableSequence(object):

    """Generalized Fibonacci to return ith number as sum of previous n numbers in sequence
    This callable class uses python 'reduce' to calculate the sum in the sequence
    
    Examples:
        1) Find the 6th number of a Fibonacci sequence after 0 and 1 
        Sequence = SummableSequence(2, (0,1))
        print(Sequence(6))
        8
        
        2) Find the 3rd mumber of Sequence of 3 numbers
        Sequence = SummableSequence(3, (5,7,11))
        print(Sequence(6)) 
        469
        
    """
    def __init__(self, n, initial):
        """ Initializing method 
    
            Args:
                n (int): the size of the initial sequence
                initial (iterable object): the initial sequence
                
        """
        self.n = n
        self.initial = list(initial)
    
    def __call__(self, i):
        """ The method that makes the class callable
    
            Args:
                i (int): the ith number in the sequence
        """
        if self.n == 2:
            k = i
        else:
            k = i + 1
        if i == 0:
            return 0
        if i == 1:
            return(reduce(lambda a,b: a+b,self.initial))
        for j in range(k-1):
            cc = 0
            cc = reduce(lambda a,b: a+b,self.initial)
            self.initial.append(cc)
            self.initial.pop(0)
        return cc
    
if __name__ == '__main__':

    print('f(100000)[-8:]', last_8(optimized_fibonacci(100000)))

    new_seq = SummableSequence(3, (5, 7, 11))
    print('new_seq(100000)[-8:]:', last_8(new_seq(100000)))
