#!/usr/bin/env python3
"""Print a pyramid to the terminal

A pyramid of height 3 would look like:

--=--
-===-
=====

"""

from argparse import ArgumentParser, RawDescriptionHelpFormatter

def line(h,l):
    """Print a line representing the pyramid at given row level 
       
    The pyramid is isosceles and filled with '='. 
    The space surrounding the pyramid is filled with '-'
              
    Args:
        h (int) = total height(rows)
        l (int) = row level
       
    Example:
       
        line (4,2)
        
        Output:
        --===--
    
    """
    x = (2*l) -1
    y = (2*h) -1
    z = int((y-x)/2)
    line = ('-' * z) + ('=' * x) + ('-' * z) + '\n'
    print (line)
    
def print_pyramid(rows):
    """Print an isosceles pyramid of a given height
           
    The pyramid is isosceles and filled with '='. 
    The space surrounding the pyramid is filled with '-'
              
    Args:
    rows(int) = total height(rows)
      
    Example:
       
        print_pyramid (3)
        
        Output:
        
        --=--
        -===-
        =====
    
    """
    # Call 'line()' in a list comprehension to print pyramid
    [line(rows, n) for n in range(1,rows+1)]
    
if __name__ == '__main__':
    parser = ArgumentParser(
        description=__doc__, formatter_class=RawDescriptionHelpFormatter,
    )
    parser.add_argument('-r', '--rows', default=10, help='Number of rows')

    args = parser.parse_args()
    print_pyramid(args.rows)
