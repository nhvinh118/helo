
Changelog
=========

0.0.0 (2019-02-12)
------------------

* First release on PyPI.
