import os
from unittest import TestCase, mock

from . import hash_str, get_csci_salt, get_user_id


class HashTests(TestCase):

    test_salt = "a0b1c2d3"
    salt_bytes = b"\xa0\xb1\xc2\xd3"

    def test_basic(self):
        self.assertEqual(
            hash_str('world!', salt='hello, ').hex()[:6], '68e656')

    def test_hash_str(self):
        val = "world!"
        salt = "hello, "
        val_bytes = val.encode()
        salt_bytes = salt.encode()
        permutations = [[val, salt], [val, salt_bytes],
                        [val_bytes, salt], [val_bytes, salt_bytes]]
        for pair in permutations:
            self.assertEqual(hash_str(*pair).hex()[:6], "68e656")

    def test_get_csci_salt(self):
        with mock.patch.dict(os.environ, dict(CSCI_SALT=self.test_salt)):
            salt = get_csci_salt()
            self.assertEqual(salt, self.salt_bytes)

    def test_get_user_id(self):
        with mock.patch.dict(os.environ, dict(CSCI_SALT=self.test_salt)):
            hashed_id = get_user_id("myusername")
            expected = hash_str("myusername", salt=self.salt_bytes).hex()[:8]
            self.assertEqual(hashed_id, expected)
