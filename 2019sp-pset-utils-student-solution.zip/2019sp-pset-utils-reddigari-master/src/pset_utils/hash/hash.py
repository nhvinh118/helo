import os
from hashlib import sha256


def get_csci_salt():
    """Get appropriate salt for CSCI E-29

    Returns:
        bytes: salt

    """
    hex_salt = os.environ.get("CSCI_SALT", "")
    return bytes.fromhex(hex_salt)


def hash_str(some_val, salt=''):
    """Convert string to hash digest

    Args:
        some_val (str or bytes): value to hash
        salt (str or bytes): salt to be used in hash, defaults to ""

    Returns:
        bytes: digest of hash of `some_val`

    """
    if isinstance(some_val, str):
        some_val = some_val.encode()
    if isinstance(salt, str):
        salt = salt.encode()
    to_hash = salt + some_val
    return sha256(to_hash).digest()


def get_user_id(username):
    """Get identifier by hashing username

    Args:
        username (str): username to hash

    Returns:
        (str): first 4 bytes of hashed username in hexadecimal

    """
    salt = get_csci_salt()
    return hash_str(username.lower(), salt=salt).hex()[:8]
