import os
from unittest import TestCase
from tempfile import TemporaryDirectory

from . import atomic_write


class FakeFileFailure(IOError):
    pass


class AtomicWriteTests(TestCase):

    def test_atomic_write(self):
        """Ensure file exists after being written successfully"""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, "asdf.txt")

            with atomic_write(fp, "w") as f:
                self.assertFalse(os.path.exists(fp))
                tmpfile = f.name
                f.write("asdf")

            self.assertFalse(os.path.exists(tmpfile))
            self.assertTrue(os.path.exists(fp))

            with open(fp) as f:
                self.assertEqual(f.read(), "asdf")

    def test_atomic_failure(self):
        """Ensure that file does not exist after failure during write"""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, "asdf.txt")

            with self.assertRaises(FakeFileFailure):
                with atomic_write(fp, "w") as f:
                    tmpfile = f.name
                    assert os.path.exists(tmpfile)
                    raise FakeFileFailure()

            assert not os.path.exists(tmpfile)
            assert not os.path.exists(fp)

    def test_file_exists(self):
        """Ensure an error is raised when a file exists"""
        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, "asdf.txt")
            # create empty file
            with open(fp, "w") as f:
                pass

            with self.assertRaises(FileExistsError):
                with atomic_write(fp, "w") as f:
                    pass

    def test_not_as_file(self):
        """
        Ensure as_file=False returns a temporary filepath.
        Opens/writes to that path, and checks that the contents end up
        in the original path passed to atomic_write().
        """
        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, "asdf.txt")

            with atomic_write(fp, "w", as_file=False) as f:
                # check that atomic_write returns a real path
                self.assertIsInstance(f, str)
                self.assertTrue(os.path.exists(f))
                # write to returned path
                with open(f, "w") as inner_f:
                    inner_f.write("qwerty")

            with open(fp) as f:
                self.assertEqual(f.read(), "qwerty")

    def test_mode(self):
        """Ensures backend raises ValueError if given 'r' or 'a' modes"""
        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, "asdf.txt")

        for mode in ("a", "r"):
            with self.assertRaises(ValueError):
                with atomic_write(fp, mode=mode):
                    pass
