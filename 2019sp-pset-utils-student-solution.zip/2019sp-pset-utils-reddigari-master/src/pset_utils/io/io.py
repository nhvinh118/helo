import os
from contextlib import contextmanager
from atomicwrites import atomic_write as _backend_writer


@contextmanager
def atomic_write(file, mode="w", as_file=True, **kwargs):
    """Write a file atomically

    Args:
        file (str): target file to write
        mode (str): mode in which to open the file; does not accept "a" or "r"
        as_file (bool): whether to yield a File object or temporary file path string
        **kwargs: anything else needed to open the file

    Raises:
        FileExistsError if target already exists
        ValueError if passed invalid mode parameter

    Examples:
    ::

        with atomic_write("hello.txt") as f:
            f.write("world!")

    """
    _, ext = os.path.splitext(file)
    with _backend_writer(file, mode=mode, suffix=ext) as f:
        if as_file:
            yield f
        else:
            yield f.name
