========
Overview
========

.. start-badges

.. list-table::
    :stub-columns: 1

    * - docs
      - |docs|
    * - tests
      - | |travis| |appveyor|
        |
    * - package
      - | |version| |wheel| |supported-versions| |supported-implementations|
        | |commits-since|
.. |docs| image:: https://readthedocs.org/projects/2019sp-pset-utils-reddigari/badge/?style=flat
    :target: https://readthedocs.org/projects/2019sp-pset-utils-reddigari
    :alt: Documentation Status

.. |travis| image:: https://travis-ci.com/csci-e-29/2019sp-pset-utils-reddigari.svg?token=ojbyxkPN7shswp2B6jNZ&branch=master
    :alt: Travis-CI Build Status
    :target: https://travis-ci.org/csci-e-29/2019sp-pset-utils-reddigari

.. |appveyor| image:: https://ci.appveyor.com/api/projects/status/github/csci-e-29/2019sp-pset-utils-reddigari?branch=master&svg=true
    :alt: AppVeyor Build Status
    :target: https://ci.appveyor.com/project/csci-e-29/2019sp-pset-utils-reddigari

.. |version| image:: https://img.shields.io/pypi/v/pset-utils.svg
    :alt: PyPI Package latest release
    :target: https://pypi.org/project/pset-utils

.. |commits-since| image:: https://img.shields.io/github/commits-since/csci-e-29/2019sp-pset-utils-reddigari/v0.0.0.svg
    :alt: Commits since latest release
    :target: https://github.com/csci-e-29/2019sp-pset-utils-reddigari/compare/v0.0.0...master

.. |wheel| image:: https://img.shields.io/pypi/wheel/pset-utils.svg
    :alt: PyPI Wheel
    :target: https://pypi.org/project/pset-utils

.. |supported-versions| image:: https://img.shields.io/pypi/pyversions/pset-utils.svg
    :alt: Supported versions
    :target: https://pypi.org/project/pset-utils

.. |supported-implementations| image:: https://img.shields.io/pypi/implementation/pset-utils.svg
    :alt: Supported implementations
    :target: https://pypi.org/project/pset-utils


.. end-badges

An example package. Generated with cookiecutter-pylibrary.

* Free software: BSD 2-Clause License

Installation
============

::

    pip install pset-utils

Documentation
=============


https://2019sp-pset-utils-reddigari.readthedocs.io/


Development
===========

To run the all tests run::

    tox

Note, to combine the coverage data from all the tox environments run:

.. list-table::
    :widths: 10 90
    :stub-columns: 1

    - - Windows
      - ::

            set PYTEST_ADDOPTS=--cov-append
            tox

    - - Other
      - ::

            PYTEST_ADDOPTS=--cov-append tox
