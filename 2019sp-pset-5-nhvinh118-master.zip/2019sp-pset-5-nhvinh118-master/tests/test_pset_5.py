
from pset_5.cli import main


def test_main():
    main([])
