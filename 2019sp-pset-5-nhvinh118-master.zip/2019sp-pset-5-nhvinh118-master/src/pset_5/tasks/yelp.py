
# -*- coding: utf-8 -*-
""" Module to perform the review of yelp data in aws s3
Module name: src.pset_5.tasks.yelp """

from dask import delayed
from dask import dataframe as dd
from luigi import Task
from luigi.parameter import BoolParameter

from pset_utils.luigi.dask.target import BaseDaskTarget, ParquetTarget, CSVTarget
from pset_utils.luigi.task import Requires, Requirement, TargetOutput, YelpReviews

class CleanedReviews(Task):
	""" Class to turn the data into a parquet data set and cache it locally
		Output is a local ParquetTarget """

	subset = BoolParameter(default=True) # Turned on by default to limit bandwidth

	def requires (self):
		# Retrieve yelp reviews into a dask dataframe
		return YelpReviews()
	
	def output(self):
		return

	def run(self):

		numcols = ["funny", "cool", "useful", "stars"] # int cols read as float
		daskdf = self.input().read_dask()

		if self.subset:
			daskdf = daskdf.get_partition(0)

		try:
			# Fill <numcols> nan's 0 
			numcols = ["funny", "cool", "useful", "stars"] # int cols read as float
			daskdf[numcols] = daskdf[numcols].fillna(value=0) 

			# Convert <numcols> to integer
			daskdf = daskdf.astype({'cool': int,
									'funny': int,
									'stars': int,
									'useful': int})

			# Set the index to <review_id>
			daskdf.set_index('review_id')

			# Drop rows where <user_id> is null or length of <review_id> is not 22
			daskdf = daskdf[(daskdf['user_id'] == 0) | (daskdf['review_id'].map(len) != 22)]
			
			# Convert dataframe to local parquet
			self.output().write_dask(daskdf, compression='gzip')

		except Exception as e:
			print(e)   

class BySomething(Task):
	""" Class to calculate the length of a review by 2 factors: 'decade' and 'stars'. 
	Length is measured by the number of characters. 

	Usage:
	- In CLI?
	- Running python -m pset_5 in Travis will display the results of each of these on the subset of data.
	- Add a flag, eg python -m pset_5 --full to run and display the results on the entire set """

	def requires(self):
		return CleanedReviews()
	
	def output(self)

	def run(self):
		print_results()
		
	def print_results(self):
		daskdf = self.output().read_dask()

		# 1. Print the average length of reviews by stars
		dout = daskdf.text.str.len().groupby(daskdf.stars).mean()
		print(dd.compute(dout))

		# 2. Print the average length of reviews by decades
		df.fillna(value = {'date': 0})
		df = df.set_index('date', blocksize=50e6)
		dout = df.text.str.len().groupby((df.index.year//10)*10).mean()
		print(dd.compute(dout))

if __name__ == "__main__": 
	pass