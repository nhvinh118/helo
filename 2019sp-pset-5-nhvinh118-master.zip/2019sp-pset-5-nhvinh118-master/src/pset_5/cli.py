# -*- coding: utf-8 -*-
""" Module that contains the command line app.
This will set the command arguments in <args> and call Stylizecc"""

import argparse
import luigi

from pset_5.tasks.yelp import BySomething

def main(args=None):

	main_arg_parser = argparse.ArgumentParser(description="parser for Yelp Reviews")
	args = main_arg_parser.parse_args()

	luigi.build([
		BySomething()
				], local_scheduler=True)

if __name__ == "__main__": 
	main()
