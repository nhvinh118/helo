# -*- coding: utf-8 -*-
""" This module implements the descriptor patterns to replace with composition the following:
- def output(self): 
- def requires(self): 

Module name: pset_utils.luigi.task 
"""
import os
import traceback

import luigi
from luigi import ExternalTask, Parameter, Task, LocalTarget

from pset_utils.luigi.dask.target import CSVTarget, ParquetTarget

class Requires:
    """Composition to replace :meth:`luigi.task.Task.requires`

    Example::

        class MyTask(Task):
            # Replace task.requires()
            requires = Requires()  
            other = Requirement(OtherTask)

            def run(self):
                # Convenient access here...
                with self.other.output().open('r') as f:
                    ...

        >>> MyTask().requires()
        {'other': OtherTask()}
    """

    def __get__(self, task, cls):
        if task is None:
            return self

        # Bind self/task in a closure
        return lambda : self(task)

    def __call__(self, task):
        """Returns the requirements of a task

        Assumes the task class has :class:`.Requirement` descriptors, which
        can clone the appropriate dependences from the task instance.

        :returns: requirements compatible with `task.requires()`
        :rtype: dict
        """

        if self.__class__ == CSVTarget:
            # get CSV requirements
            return CSVRequirement()

        elif self.__class__ == ParquetTarget:
            # get parquet requirements
            return ParquetRequirement()
            
        else:
            pass

class Requirement:
    """ This class implements requirements """
    
    def __init__(self, task_class, **params):
        pass

    def __get__(self, task, cls):
        if task is None:
            return self

        return task.clone(
            self.task_class,
            **self.params)

class CSVRequirement(Requirement):
    """ Requirements for CSV """

    def __init__(self, factory):
        self.factory = factory

    def __get__(self, task, owner):
        return self.factory(task)

class ParquetRequirement(Requirement):
    """ Requirements for Parquet """

    def __init__(self, factory):
        self.factory = factory

    def __get__(self, task, owner):
        return self.factory(task)

class TargetOutput:
    """Composition to replace :meth:`luigi.task.Task.output`
    Descriptor that can be used to generate a luigi target using a salted task id, inside the task module """
    
    def __init__(self, file_pattern='{task.__class__.__name__}',
        ext='.txt', target_class=LocalTarget, **target_kwargs):
        # The string patterns in file_pattern are intended to be used as follows:
        # '{task.param}-{var}.txt'.format(task=task, var='world')
        # 'hello-world.txt'
        pass

    def __get__(self, task, cls):
        if task is None:
            return self
        return lambda: self(task)

    def __call__(self, task):
        # Determine the path etc here..
               
        return self.LocalTarget(self.file_pattern.format(task=task) + self.ext)

class YelpReviews(ExternalTask):
    """ Create a Luigi External Task that uses the appropriate dask target """

    YELPDATA_ROOT = "s3://cscie29-data/pset5/yelp_data/" # S3 path of yelp data
    mflag = "yelp_subset_*.csv"
    mpath = YELPDATA_ROOT

    # Call CSVTarget to get S3 data into the dask dataframe
    output = TargetOutput(file_pattern=mpath, target_class=CSVTarget, flag=mflag)

    return CSVTarget(mpath, flag=mflag)