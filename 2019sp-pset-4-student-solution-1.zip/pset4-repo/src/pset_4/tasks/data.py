import os

from luigi import ExternalTask, Parameter, Task, LocalTarget
from luigi.contrib.s3 import S3Target
from luigi.format import Nop


class ContentImage(ExternalTask):
    IMAGE_ROOT = "s3://cscie29-data/pset4/data"

    image = Parameter("image")

    def output(self):
        target = os.path.join(self.IMAGE_ROOT, self.image)
        return S3Target(target, format=Nop)


class SaveModel(ExternalTask):
    MODEL_ROOT = "s3://cscie29-data/pset4/model"

    model = Parameter("model")

    def output(self):
        target = os.path.join(self.MODEL_ROOT, self.model)
        return S3Target(target, format=Nop)


class CopyS3ModelLocally(Task):
    MODEL_ROOT = os.path.join('data', 'model')
    model = Parameter("model")

    def requires(self):
        return SaveModel(model=self.model)

    def output(self):
        return  LocalTarget(os.path.join(self.MODEL_ROOT, self.model), format=Nop)

    def run(self):
        with self.input().open(mode='r') as input:
            with self.output().open(mode='w') as out:
                out.write(input.read())


class CopyS3ImageLocally(Task):
    IMAGE_ROOT = os.path.join('data', 'image')
    image = Parameter("image")

    def requires(self):
        return ContentImage(image=self.image)

    def output(self):
        return LocalTarget(os.path.join(self.IMAGE_ROOT, self.image), format=Nop)

    def run(self):
        with self.input().open(mode='r') as input:
            with self.output().open(mode='w') as out:
                out.write(input.read())
