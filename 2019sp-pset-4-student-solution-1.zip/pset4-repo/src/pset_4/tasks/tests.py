import os
from PIL import Image
from PIL import ImageDraw
from unittest import TestCase
from luigi.format import Nop
from luigi import build, Parameter
from luigi import LocalTarget
from tempfile import TemporaryDirectory
from pset_4.tasks.data import CopyS3ModelLocally, CopyS3ImageLocally


class CopyS3ModelLocallyTest(CopyS3ModelLocally):
    MODEL_ROOT = Parameter()

    # Overriding the input method to return test file
    def input(self):
        return LocalTarget(os.path.join(self.MODEL_ROOT, "test.pth"), format=Nop)

    # Overriding requires method to create custom task path
    def requires(self):
        pass

class CopyS3ImageLocallyTest(CopyS3ImageLocally):

    IMAGE_ROOT =  Parameter()

    # Overriding the input method to return test file
    def input(self):
        return LocalTarget(os.path.join(self.IMAGE_ROOT, "test.jpg"), format=Nop)

    # Overriding requires method to create custom task path
    def requires(self):
        pass


class TaskTest(TestCase):

    def test_model(self):
        with TemporaryDirectory() as tmp:
            file = os.path.join(tmp, 'test.pth')
            with open(file, mode="w") as temp_file_name:
                temp_file_name.write("{0}\n{1}\n{2}".format("test0",
                                                            "test1",
                                                            "test2"))
            build([CopyS3ModelLocallyTest(model="model.pth", MODEL_ROOT=tmp)], local_scheduler=True)
            self.assertTrue(os.path.exists(os.path.join(tmp, "model.pth")))

    def test_image(self):

        with TemporaryDirectory() as tmp:

            # https://stackoverflow.com/questions/42844624/create-image-through-python
            # to create a sample image

            img_name = "test.jpg"

            img = Image.new('RGB', (500, 500))
            draw = ImageDraw.Draw(img)

            draw.text((250, 250), "Hello this is a test", (255, 255, 255))
            file = os.path.join(tmp, img_name)

            img.save(file)

            build([CopyS3ImageLocallyTest(image="image.jpg", IMAGE_ROOT=file)], local_scheduler=True)
            self.assertTrue(os.path.exists(os.path.join(tmp, img_name)))
