import os

import luigi
from pset_utils.luigi.target import SuffixPreservingLocalTarget

from neural_style.neural_style import stylize
from pset_4.tasks.data import CopyS3ImageLocally, CopyS3ModelLocally


class Stylize(luigi.Task):
    IMAGE_ROOT = os.path.join("data", "image")
    model = luigi.Parameter("model")
    image = luigi.Parameter("image")

    def requires(self):
        return {
            'image': CopyS3ImageLocally(image=self.image),
            'model': CopyS3ModelLocally(model=self.model)
        }

    def output(self):
        image, ext = os.path.splitext(self.image)
        # the output image file name will image_model_style.ext
        out_image = "{0}_{1}_style{2}".format(image, os.path.splitext(self.model)[0], ext)
        return SuffixPreservingLocalTarget(os.path.join(self.IMAGE_ROOT, out_image), format=luigi.format.Nop)

    def run(self):
        inputs = self.input()
        with self.output().temporary_path() as temp_output_path:
            class args:
                content_image = inputs['image'].path
                model = inputs['model'].path
                output_image = temp_output_path
                cuda = 0
                content_scale = 1
                export_onnx = ''

            stylize(args)

