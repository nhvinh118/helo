from neural_style.neural_style import main

if __name__ == '__main__':
    main()
