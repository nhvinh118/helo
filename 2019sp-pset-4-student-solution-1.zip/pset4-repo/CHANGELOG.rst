
Changelog
=========

0.0.0 (2019-03-05)
------------------

* First release on PyPI.
