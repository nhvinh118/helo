=====
Usage
=====

To use Pset 4 in a project::

	import pset_4
