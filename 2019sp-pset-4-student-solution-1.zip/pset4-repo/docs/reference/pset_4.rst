pset_4
======

.. testsetup::

    from pset_4 import *

.. automodule:: pset_4
    :members:
