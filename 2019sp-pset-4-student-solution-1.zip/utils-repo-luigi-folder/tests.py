import os
from tempfile import TemporaryDirectory
from unittest import TestCase

from luigi import Task, build
import dask.dataframe as dd
import pandas as pd

from .dask.target import ParquetTarget
from .target import suffix_preserving_atomic_file, SuffixPreservingLocalTarget
from .task import SaltedOutput


class SuffixPreservingAtomicFileTest(TestCase):

    def test_generate_temp_path(self):
        """Ensure that the temp_file generated preserves the suffix"""

        with TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'asdf.txt')
            sptf = suffix_preserving_atomic_file(path)
            # Validating if the path is equal to the name of the file
            self.assertEquals(sptf.path, path)

            # Validating that temp_file name and the actual filename are not same
            self.assertNotEquals(sptf.tmp_path, path)

            # Validating that the suffix is preserved
            temp_file_base, temp_file_ext = os.path.splitext(sptf.tmp_path)
            path_base, path_ext = os.path.splitext(path)
            self.assertEquals(temp_file_ext, path_ext)


class SuffixPreservingLocalTargetTest(TestCase):
    """Ensure that
    1. the temp_file generated preserves the suffix
    2. SuffixPreservingLocalTarget uses suffix_preserving_atomic_file as atomic_provider
    """

    def test_suffix_preserving_local_target_test(self):
        with TemporaryDirectory() as tmp:
            path = os.path.join(tmp, 'asdf.txt')
            target = SuffixPreservingLocalTarget(path)
            with target.temporary_path() as tmp_path:
                # Validating that the suffix is preserved
                temp_file_base, temp_file_ext = os.path.splitext(tmp_path)
                path_base, path_ext = os.path.splitext(path)
                self.assertEquals(temp_file_ext, path_ext)

