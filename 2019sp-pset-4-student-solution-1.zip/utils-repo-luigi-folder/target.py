import os
import random
from contextlib import contextmanager

from luigi.local_target import LocalTarget, atomic_file


class suffix_preserving_atomic_file(atomic_file):
    def generate_tmp_path(self, path):
        base_path, file_name = os.path.split(path)
        return os.path.join(base_path, "luigi-tmp-{0}-{1}".format(random.randrange(0, 1e10), file_name))


class BaseAtomicProviderLocalTarget(LocalTarget):
    # Allow some composability of atomic handling
    atomic_provider = atomic_file

    def open(self, mode='r'):
        rwmode = mode.replace('b', '').replace('t', '')

        if rwmode == 'w':
            self.makedirs()
            return self.format.pipe_writer(self.atomic_provider(self.path))

        return super(self).open(mode=mode)

    @contextmanager
    def temporary_path(self):
        # NB: unclear why LocalTarget doesn't use atomic_file in its implementation
        self.makedirs()
        with self.atomic_provider(self.path) as af:
            yield af.tmp_path


class SuffixPreservingLocalTarget(BaseAtomicProviderLocalTarget):
    """SuffixPreservingLocalTarget class represents a Local Target
    which is atomic as well as suffix preserving """
    atomic_provider = suffix_preserving_atomic_file
