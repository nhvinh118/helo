'''
Part 2: Inspect the happenings of a simple decorator
'''
# https://python-3-patterns-idioms-test.readthedocs.io/en/latest/PythonDecorators.html
# PythonDecorators/my_decorator.py
class my_decorator(object):

    def __init__(self, f):
        print("inside my_decorator.__init__()")
        self.f = f # Prove that function definition has completed

    def __call__(self):
        print("inside my_decorator.__call__()")
        self.f()


@my_decorator
def aFunction():
    print("inside aFunction()")

print("Finished decorating aFunction()")

aFunction()
