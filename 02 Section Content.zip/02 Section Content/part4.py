'''
Part 4: Build out the function from part1 using wraps - printing a string and the hash value
'''
import hashlib
from functools import wraps

# implement decorator here
def print_hash(func):

    @wraps(func)
    def func_wrapper(some_string):
        func(some_string)
        result = hashlib.md5(str.encode(some_string))
        print(result.hexdigest())
    return func_wrapper

@print_hash
def print_string(some_string):
    print(some_string)

print_string("Autumn is nice.")