'''
Part 1: Print a string and the hash of that string, not using decorators
'''

import hashlib

def print_string(some_string=None):

	def print_hash(some_string):
		result = hashlib.md5(str.encode(some_string))
		print("hash value: " + result.hexdigest())

	print(some_string)
	print_hash(some_string)


print_string("Autumn is nice.")
