from django.apps import AppConfig


class MigrationpracticeConfig(AppConfig):
    name = 'MigrationPractice'
