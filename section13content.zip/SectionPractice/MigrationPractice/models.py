from django.db import models

status_choices = (
    ('0', 'Requested'),
    ('6', 'Bulk-Up: Ready To Go'),
    ('7', 'DNA Bulk-Up'),
    ('1', 'Transfection: Ready To Go'),
    ('2', 'Transfected'),
    ('3', 'In Purification'),
    ('4', 'In Analysis'),
    ('5', 'Completed'),
)

class CellRequest(models.Model):
    status           = models.CharField(max_length=255, choices=status_choices)
    request_date     = models.DateField(auto_now_add=True)
    short_name       = models.TextField()
    notes            = models.TextField(null=True, blank=True)

    # add this field
    requested_completion_date = models.DateField(null=True, blank=True)

    # add this field and compute: priority requests are those whose completion date falls on a Monday
    priority_request = models.BooleanField(null=False)

    late = models.BooleanField()

    def __str__(self):
      return u'%s' % self.short_name