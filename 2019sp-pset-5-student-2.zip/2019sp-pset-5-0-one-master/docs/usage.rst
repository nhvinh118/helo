=====
Usage
=====

To use Pset 5 in a project::

	import pset_5
