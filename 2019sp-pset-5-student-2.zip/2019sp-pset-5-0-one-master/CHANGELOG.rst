
Changelog
=========

0.0.0 (2019-04-14)
------------------

* First release on PyPI.
