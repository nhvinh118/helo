from luigi import Task, ExternalTask
from luigi import Parameter, BoolParameter
from pset_utils.luigi.dask.target import CSVTarget, ParquetTarget
from pset_utils.luigi.task import Requires, Requirement, TargetOutput

class YelpReviews(ExternalTask):
    """ Luigi ExternalTask that points to an S3 saved model

    Default pattern is "s3://cscie29-data/pset5/yelp_data/yelp_subset_*.csv".

    Parameters:
        s3_root: str, name of saved data parent directory
        s3_glob: str, glob pattern of data file names
        s3_ext: str, extension added to end of glob

    Outputs:
        A CSVTarget instance
    """
    s3_root = Parameter(default="s3://cscie29-data/pset5/yelp_data/")
    s3_glob = Parameter(default="yelp_subset_*")
    s3_ext = Parameter(default=".csv")

    output = TargetOutput('{task.s3_root}', ext='{task.s3_ext}',
                          target_class=CSVTarget, glob='{task.s3_glob}', flag = None)


class CleanedReviews(Task):
    """ Task to clean Yelp Review data.

    The Yelp reviews input are from an External Task that specifies files in S3.
    Rows with NULL date, user_id or invalid review_id are dropped. The resulting output
    is indexed on review_id.

    This Task can either process one partition or the full data set depending on the subset
    parameter.

    Parameters:
        subset: bool, True to process just one partition, False to process
            the entire dataset, default: True
        data_root: str, base directory to store output files

    Output:
        Partitioned Dataframe stored in compressed Parquet format in
            {self.data_root}/subset-{self.subset}/

    """
    subset = BoolParameter(default=True)
    data_root = Parameter(default="./data/")

    requires = Requires()
    input_data = Requirement(YelpReviews)

    output = TargetOutput('{task.data_root}', ext='subset-{task.subset}/',
                          target_class=ParquetTarget, flag = "_SUCCESS")

    def run(self):
        """ Clean Yelp Review data from Task input and stores dataframe in Parquet format.

        The cleaning steps performed on the data are:
            1. any NULL user_id rows are dropped
            2. any rows with len(review_id) != 22 are dropped
            3. any NULL date rows are dropped
        The review_id column is then used as index.
        """
        numcols = ["funny", "cool", "useful", "stars"]
        dsk = self.input()['input_data'].read_dask(parse_dates=['date'], dtype={c:'float' for c in numcols})

        if self.subset:
            dsk = dsk.get_partition(0)

        # perform data cleaning
        dsk = dsk[~dsk.user_id.isnull()]
        dsk = dsk[dsk.review_id.str.len()==22]
        dsk = dsk[~dsk.date.isnull()]

        # set index
        dsk = dsk.set_index('review_id')
        dsk[numcols] = dsk[numcols].fillna(0).astype(int)

        out = dsk
        self.output().write_dask(out, compression='gzip')


class AnalysisBase(Task):
    """ This is the base class for data analysis calculations.

    Currently, this is subclassed by ByDate and ByStars Tasks.
    Input is taken from CleanedReviews output. These are cleaned Yelp reivews
    stored in Parquet files.

    The actual analysis is calculated in calc_analysis(), which is to be
    overridden in subclasses.

    The results are dataframes and saved in Parquet format. This base class
    expects a "sub_dir" parameter to be defined in the subclass. This should
    denote the specific analysis performed by the subclass. The results are then
    stored inside this sub directory.

    Parameters:
        subset: bool, True to process just one partition, False to process
            the entire dataset, default: True
        calc_root: str, base directory to store output files

    Output:
        Dataframe stored in compressed Parquet format in
            {task.calc_root}/{task.sub_dir}/subset-{task.subset}/
    """

    subset = BoolParameter(default=True)
    calc_root = Parameter(default="./data/")

    requires = Requires()
    input_data = Requirement(CleanedReviews)

    # the output references a "sub_dir" parameter, which is expected to be defined
    # in a subclass
    output = TargetOutput('{task.calc_root}{task.sub_dir}', ext='subset-{task.subset}/',
                          target_class=ParquetTarget, flag = "_SUCCESS")

    def calc_analysis(self, df):
        """ This is to be overridden by the subclass. """
        raise NotImplementedError

    def run(self):
        """ calls "calc_analysis() to do the actual computation. """
        df = self.input()['input_data'].read_dask(columns=['stars', 'date', 'text'])

        out_dd = self.calc_analysis(df)
        self.output().write_dask(out_dd, write_index=True, compression='gzip')


class AnalysisReportBase(Task):
    """ Base class for analysis reporting.

    A subclass of this class is the final stage of analysis pipeline and should always run to provide
    screen output. Therefore, no "output" is defined here, and the subclass also should not define an output.
    The "complete()" method here also always returns False so that run() can be triggered.

    This class does not do any computation and only prints previously computed results to screen.
    Luigi should be able to schedule in such a way that repeated computation is avoided. The subclass
    is expected to provide "input_data" Requirement. This will be displayed on screen.

    Parameters:
        subset: bool, True to process just one partition, False to process
            the entire dataset, default: True
        calc_root: str, base directory to store output files

    Output:
        screen output of the "input_data" Requirement, to be defined in subclass
    """
    subset = BoolParameter(default=True)
    calc_root = Parameter(default="./data/")

    requires = Requires()

    def complete(self):
        """ To ensure that this class always run, it does not have output() but has this function that
        returns False. """
        return False

    def run(self):
        """ Reads from "input_data" Requirement and prints results to screen. """
        result_df = self.input()['input_data'].read_dask()
        print(result_df.compute())


class ByDecadeCalc(AnalysisBase):
    """ This class computes the average length of reviews by decades.

    This class defines the concrete implementation of "calc_analysis()", which performs
    the actual group-by and averaging computations.

    This class also sets the "sub_dir" parameter so that results are stored in the appropriate
    directory. The base will then go down one more directory level to specify if the "subset" parameter
    is set.

    Parameters:
        sub_dir: str, subdirectory to store output of this class.
    """

    sub_dir = Parameter(default="by_decade/")

    def calc_analysis(self, df):
        """ Performs actual computation of text length average per decade.

        Args:
            df: dataframe containing Yelp reviews

        Returns:
            dataframe, one row per decade; column "strlen" contain the average review length
        """

        df['strlen'] = df.text.str.len()
        df['decade'] = ((df.date.dt.year // 10) * 10).astype(int)

        return df.groupby('decade').strlen.mean().to_frame()


class ByDecade(AnalysisReportBase):
    """ Reporting Task for "by decade" analysis.

    This Task always runs. It only displays stored results from files but does not do any computations.
    It specifies ByDecadeCalc as the "input_data" Requirement for the base class, which will trigger
    the actual computation only if necessary.
    """
    input_data = Requirement(ByDecadeCalc)


class ByStarsCalc(AnalysisBase):
    """ This class computes the average length of reviews by star rating.

    This class defines the concrete implementation of "calc_analysis()", which performs
    the actual group-by and averaging computations.

    This class also sets the "sub_dir" parameter so that results are stored in the appropriate
    directory. The base will then go down one more directory level to specify if the "subset" parameter
    is set.

    Parameters:
        sub_dir: str, subdirectory to store output of this class.
    """
    sub_dir = Parameter(default="by_stars/")

    def calc_analysis(self, df):
        """ Performs actual computation of text length average for each star rating.

        Args:
            df: dataframe containing Yelp reviews

        Returns:
            dataframe, one row per star rating; column "strlen" contain the average review length
        """

        df['strlen'] = df.text.str.len()

        return df.groupby('stars').strlen.mean().to_frame()


class ByStars(AnalysisReportBase):
    """ Reporting Task for "by stars" analysis.

    This Task always runs. It only displays stored results from files but does not do any computations.
    It specifies ByDecadeCalc as the "input_data" Requirement for the base class, which will trigger
    the actual computation only if necessary.
    """
    input_data = Requirement(ByStarsCalc)
