#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `pset_5` package."""

import os
from tempfile import TemporaryDirectory
from unittest import TestCase
import moto
import boto3
import pathlib
import pandas as pd
import numpy as np

import dask.dataframe as dd
from luigi import build, Task, Parameter

from pset_utils.luigi.task import Requires, Requirement

from .tasks import YelpReviews, CleanedReviews, ByDecadeCalc, ByStarsCalc

def make_df():
    """ Makes a pandas dataframe with dummy data.

    The data format mimics that of the Yelp Review dataframe."""

    my_df = pd.DataFrame({"review_id": ["1234a67890123456789012",
                                        "1234a67890123456789013",
                                        "1234a67890123456789014",
                                        "1234a678901234567890"],
                         "user_id": ["abc", "asdfasd", None, "asdfasd"],
                         "business_id": ["abc", "asdfsa", "asdfsa", "asdfasd"],
                         "stars": [1,2,3,4],
                         "date": [pd.datetime.strptime('2019-01-01', '%Y-%m-%d'),
                                  None,
                                  pd.datetime.strptime('2019-02-01', '%Y-%m-%d'),
                                  pd.datetime.strptime('2019-03-01', '%Y-%m-%d')],
                         "text": ["abc", "asdfsa", "asdfsa", "asdfasd"],
                         "useful": [None,2,3,4],
                         "funny": [1,2,3,4],
                         "cool": [1,2,3,4]})

    # make a few more rows by duplicating the data
    # we are duplicating my_df 2^3 times here, each time in the loop doubles the size
    for i in range(3):
        my_df = my_df.append(my_df)
    my_df = my_df.set_index('review_id').reset_index()
    df_sequence = ["{:04d}".format(x) for x in range(len(my_df))]
    my_df.review_id = np.array(df_sequence) + my_df.review_id.str.slice(4)

    return my_df


def compare_dfs(df1, df2, intcols=[], null_val=0):
    " Compares two dataframes "
    df1 = df1.sort_values(list(df1.columns)).fillna(null_val).set_index(df1.columns[0]).reset_index()
    df2 = df2.sort_values(list(df2.columns)).fillna(null_val).set_index(df1.columns[0]).reset_index()

    if len(intcols) > 0:
        df1[intcols] = df1[intcols].astype('int32')
        df2[intcols] = df2[intcols].astype('int32')

    return df1.equals(df2)


@moto.mock_s3
def mock_s3_setup(local_fp, s3_path):
    """ Creates a set of dummy CSV files and uploads them to a mock S3 bucket.

    The CSV files are in a directory and have the same format as the Yelp Reviews data set
    in Pset 5. When read into a dataframe, the structure should be compatible.
    """
    df = dd.from_pandas(make_df(), npartitions=4)
    flist = [pathlib.Path(x).name for x in dd.to_csv(df, os.path.join(local_fp, 'yelp_subset_*.csv'), index=False)]

    s3 = boto3.client('s3')
    s3.create_bucket(Bucket='cscie29-data')

    for f in flist:
        s3_target_path = pathlib.Path(s3_path).joinpath(f).as_posix()
        local_path = os.path.join(local_fp, f)
        s3.upload_file(local_path, 'cscie29-data', s3_target_path)
        os.unlink(local_path)


class S3ExtTargetTest(TestCase):

    @moto.mock_s3
    def test_s3_review_target(self):
        " Ensure that the S3 Yelp Reviews can be accessed. "

        class TestTask(Task):
            requires = Requires()
            input_data = Requirement(YelpReviews)

            def complete(self):
                """ To ensure that this class always run, it does not have output() but has this function that
                returns False. """
                return False

            def run(self):
                dsk = self.input()['input_data'].read_dask(parse_dates=['date'])

                assert compare_dfs(make_df(), dsk.compute())

        with TemporaryDirectory() as tmp:
            mock_s3_setup(tmp, 'pset5/yelp_data/')
            assert build([TestTask()], local_scheduler=True)

class S3CleanTest(TestCase):

    @moto.mock_s3
    def test_clean_review(self):
        """ Ensure that the input dataframe is cleaned.

        1. any rows with len(review_id) != 22 are dropped
        2. any NULL user_id rows are dropped
        3. any NULL date rows are dropped
        """

        class TestTask(Task):
            subset = Parameter(default=True)

            requires = Requires()
            input_data = Requirement(CleanedReviews)

            def complete(self):
                """ To ensure that this class always run, it does not have output() but has this function that
                returns False. """
                return False

            def run(self):
                dsk = self.input()['input_data'].read_dask()

                # only rows with the review_id ending "012" have correct data
                # there should be 4 rows with this id
                expected_df = make_df()
                expected_df = expected_df[expected_df.review_id.str.slice(-3) == "012"]
                expected_df = expected_df.set_index("review_id")

                intcols = ["funny", "cool", "useful", "stars"]
                assert compare_dfs(expected_df, dsk.compute(), intcols=intcols)

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                mock_s3_setup(tmp, 'pset5/yelp_data/')
                assert build([TestTask(subset=False)], local_scheduler=True)
            finally:
                os.chdir(current_dir)


    @moto.mock_s3
    def test_clean_review_success_flag_and_subset_true_dirname(self):
        """ Ensure that the _SUCCESS flag is set upon successful completion.
        Also ensure that the output is written to data/subset-True (default) directory.
        """

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                mock_s3_setup(tmp, 'pset5/yelp_data/')
                assert build([CleanedReviews()], local_scheduler=True)

                assert os.path.exists(os.path.join(tmp, 'data', 'subset-True', '_SUCCESS'))
            finally:
                os.chdir(current_dir)


    @moto.mock_s3
    def test_clean_review_atomicity(self):
        """ Ensure that the _SUCCESS flag is NOT set when processing cannot complete normally.

        Here we firsts "touch" part.2.parquet and then make it read-only. The clean review task
        should then fail half way and no _SUCCESS flag should be generated.
        """

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                # create "data/subset-False/part.2.parquet" and make it read-only
                part_file = os.path.join(tmp, 'data', 'subset-False', 'part.2.parquet')
                os.mkdir(os.path.join(tmp, 'data'))
                os.mkdir(os.path.join(tmp, 'data', 'subset-False'))
                with open(part_file, 'wb') as f:
                    f.write(b"abc")
                os.chmod(part_file, 0o000)

                mock_s3_setup(tmp, 'pset5/yelp_data/')

                # expect to fail due to PermissionError, use "assert not" here
                assert not build([CleanedReviews(subset=False)], local_scheduler=True)

                # make sure the _SUCCESS flag is not there!
                assert not os.path.exists(os.path.join(tmp, 'data', 'subset-False', '_SUCCESS'))
            finally:
                os.chdir(current_dir)
                # need to set permissions back to allow clean up
                os.chmod(part_file, 0o660)


    @moto.mock_s3
    def test_clean_review_subset_false_dirname(self):
        """ Ensure that the _SUCCESS flag is set upon successful completion.
        Also ensure that the output is written to data/subset-False (full processing) directory.
        """

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                mock_s3_setup(tmp, 'pset5/yelp_data/')
                assert build([CleanedReviews(subset=False)], local_scheduler=True)

                assert os.path.exists(os.path.join(tmp, 'data', 'subset-False', '_SUCCESS'))
            finally:
                os.chdir(current_dir)


    @moto.mock_s3
    def test_clean_review_subset_false_partitions(self):
        """ Ensure that the full dataset is processed when subset=False.."""

        class TestTask(Task):
            subset = Parameter(default=True)

            requires = Requires()
            input_data = Requirement(CleanedReviews)

            def complete(self):
                """ To ensure that this class always run, it does not have output() but has this function that
                returns False. """
                return False

            def run(self):
                dsk = self.input()['input_data'].read_dask()
                # 4 partitions are expected; this is set in mock_s3_setup()
                assert dsk.npartitions == 4

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                mock_s3_setup(tmp, 'pset5/yelp_data/')
                assert build([TestTask(subset=False)], local_scheduler=True)
            finally:
                os.chdir(current_dir)


    @moto.mock_s3
    def test_clean_review_subset_true_partitions(self):
        """ Ensure that only one partition is processed when subset=True.."""

        class TestTask(Task):
            subset = Parameter(default=True)

            requires = Requires()
            input_data = Requirement(CleanedReviews)

            def complete(self):
                """ To ensure that this class always run, it does not have output() but has this function that
                returns False. """
                return False

            def run(self):
                dsk = self.input()['input_data'].read_dask()
                # 1 partitions is expected if subset=True
                assert dsk.npartitions == 1

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                mock_s3_setup(tmp, 'pset5/yelp_data/')
                assert build([TestTask(subset=True)], local_scheduler=True)
            finally:
                os.chdir(current_dir)


class ByDecadeCalcTest(TestCase):

    @moto.mock_s3
    def test_by_decade_success_flag_and_subset_true_dirname(self):
        """ Ensure that the _SUCCESS flag is set upon successful completion.
        Also ensure that the output is written to data/by_decade/subset-True (default) directory.
        """

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                mock_s3_setup(tmp, 'pset5/yelp_data/')
                assert build([ByDecadeCalc()], local_scheduler=True)

                assert os.path.exists(os.path.join(tmp, 'data', 'by_decade', 'subset-True', '_SUCCESS'))
            finally:
                os.chdir(current_dir)


    @moto.mock_s3
    def test_by_decade_atomicity(self):
        """ Ensure that the _SUCCESS flag is NOT set when processing cannot complete normally.

        Here we firsts "touch" part.0.parquet and then make it read-only. The clean review task
        should then fail and no _SUCCESS flag should be generated.
        """

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                # create "data/by_decade/subset-False/part.0.parquet" and make it read-only
                part_file_parent = os.path.join(tmp, 'data', 'by_decade', 'subset-False')
                part_file = os.path.join(part_file_parent, 'part.0.parquet')
                os.mkdir(os.path.join(tmp, 'data'))
                os.mkdir(os.path.join(tmp, 'data', 'by_decade'))
                os.mkdir(part_file_parent)
                with open(part_file, 'wb') as f:
                    f.write(b"abc")
                os.chmod(part_file, 0o000)

                mock_s3_setup(tmp, 'pset5/yelp_data/')

                # expect to fail due to PermissionError, use "assert not" here
                assert not build([ByDecadeCalc(subset=False)], local_scheduler=True)

                # make sure the _SUCCESS flag is not there!
                assert not os.path.exists(os.path.join(part_file_parent, '_SUCCESS'))
            finally:
                os.chdir(current_dir)
                # need to set permissions back to allow clean up
                os.chmod(part_file, 0o660)


    @moto.mock_s3
    def test_by_decade_subset_false_dirname(self):
        """ Ensure that the _SUCCESS flag is set upon successful completion.
        Also ensure that the output is written to data/by_decade/subset-False (full processing) directory.
        """

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                mock_s3_setup(tmp, 'pset5/yelp_data/')
                assert build([ByDecadeCalc(subset=False)], local_scheduler=True)

                assert os.path.exists(os.path.join(tmp, 'data', 'by_decade', 'subset-False', '_SUCCESS'))
            finally:
                os.chdir(current_dir)


    @moto.mock_s3
    def test_by_decade_correctness(self):
        """ Ensure ByDecadeCalc gives correct result. """

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                mock_s3_setup(tmp, 'pset5/yelp_data/')
                assert build([ByDecadeCalc(subset=False)], local_scheduler=True)

                result_path = os.path.join(tmp, 'data', 'by_decade', 'subset-False')
                assert os.path.exists(os.path.join(result_path, '_SUCCESS'))

                df = dd.read_parquet(os.path.join(result_path))

                # check the results
                self.assertAlmostEqual(df.loc[2010].strlen.compute().to_numpy()[0], 3.0)
            finally:
                os.chdir(current_dir)




class ByStarsCalcTest(TestCase):

    @moto.mock_s3
    def test_by_stars_success_flag_and_subset_true_dirname(self):
        """ Ensure that the _SUCCESS flag is set upon successful completion.
        Also ensure that the output is written to data/by_stars/subset-True (default) directory.
        """

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                mock_s3_setup(tmp, 'pset5/yelp_data/')
                assert build([ByStarsCalc()], local_scheduler=True)

                assert os.path.exists(os.path.join(tmp, 'data', 'by_stars', 'subset-True', '_SUCCESS'))
            finally:
                os.chdir(current_dir)


    @moto.mock_s3
    def test_by_stars_atomicity(self):
        """ Ensure that the _SUCCESS flag is NOT set when processing cannot complete normally.

        Here we firsts "touch" part.0.parquet and then make it read-only. The clean review task
        should then fail and no _SUCCESS flag should be generated.
        """

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                # create "data/by_stars/subset-False/part.0.parquet" and make it read-only
                part_file_parent = os.path.join(tmp, 'data', 'by_stars', 'subset-False')
                part_file = os.path.join(part_file_parent, 'part.0.parquet')
                os.mkdir(os.path.join(tmp, 'data'))
                os.mkdir(os.path.join(tmp, 'data', 'by_stars'))
                os.mkdir(part_file_parent)
                with open(part_file, 'wb') as f:
                    f.write(b"abc")
                os.chmod(part_file, 0o000)

                mock_s3_setup(tmp, 'pset5/yelp_data/')

                # expect to fail due to PermissionError, use "assert not" here
                assert not build([ByStarsCalc(subset=False)], local_scheduler=True)

                # make sure the _SUCCESS flag is not there!
                assert not os.path.exists(os.path.join(part_file_parent, '_SUCCESS'))
            finally:
                os.chdir(current_dir)
                # need to set permissions back to allow clean up
                os.chmod(part_file, 0o660)


    @moto.mock_s3
    def test_by_stars_subset_false_dirname(self):
        """ Ensure that the _SUCCESS flag is set upon successful completion.
        Also ensure that the output is written to data/by_stars/subset-False (full processing) directory.
        """

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                mock_s3_setup(tmp, 'pset5/yelp_data/')
                assert build([ByStarsCalc(subset=False)], local_scheduler=True)

                assert os.path.exists(os.path.join(tmp, 'data', 'by_stars', 'subset-False', '_SUCCESS'))
            finally:
                os.chdir(current_dir)


    @moto.mock_s3
    def test_by_stars_correctness(self):
        """ Ensure ByStarsCalc gives correct result. """

        with TemporaryDirectory() as tmp:
            current_dir = os.getcwd()
            os.chdir(tmp)
            try:
                mock_s3_setup(tmp, 'pset5/yelp_data/')
                assert build([ByStarsCalc(subset=False)], local_scheduler=True)

                result_path = os.path.join(tmp, 'data', 'by_stars', 'subset-False')
                assert os.path.exists(os.path.join(result_path, '_SUCCESS'))

                df = dd.read_parquet(os.path.join(result_path))

                # check the results
                self.assertAlmostEqual(df.loc[1].strlen.compute().to_numpy()[0], 3.0)
            finally:
                os.chdir(current_dir)

