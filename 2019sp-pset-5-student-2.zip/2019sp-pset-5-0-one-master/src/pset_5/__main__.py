"""
Entrypoint module, in case you use `python -mpset_5`.
"""
from pset_5.cli import main

if __name__ == "__main__":
    main()
