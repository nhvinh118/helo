"""
Module that contains the command line app.
"""

import argparse
from luigi import build
from .tasks import ByDecade, ByStars
import luigi.interface
import luigi.scheduler

parser = argparse.ArgumentParser(description='Pset 5 Analysis')
# Flag to specify if a subset of data is to be processed.
parser.add_argument('-f', '--full', action='store_true', help="process full set of data")
# By default, INFO and DEBUG messages from Luigi scheduler is suppressed. This flag turns
# them back on.
parser.add_argument('-d', '--debug', action='store_true', help="process full set of data")

def main(args=None):
    """ Entry point to Pset_5.

    The results of by-decads and by-stars review length analysis will be printed to screen.

    Args:
        --full -f: command line option. If set, the entire dataset is used. If not set, only
            one partition is processed.
        --debug -d: command line option. If set, INFO and DEBUG messages from Luigi scheduler are
            also printed to screen. If not, only WARNING and above messages are printed.

    Outputs:
        by-decades and b-stars analysis of reivew lengths are printed to screen.
    """
    args = parser.parse_args(args=args)

    # Suppress Luigi DEBUG and INFO messages unless --debug flag is set.
    if args.debug:
        log_level = "DEBUG"
    else:
        log_level = "WARNING"
    luigi.interface.core.log_level = log_level

    build([ByDecade(subset=(not args.full)), ByStars(subset=(not args.full))], local_scheduler=True)
