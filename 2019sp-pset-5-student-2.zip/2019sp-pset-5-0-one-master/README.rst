========
Overview
========

.. start-badges

.. list-table::
    :stub-columns: 1

    * - docs
      - |docs|
    * - tests
      - | master |travis-master|
        | develop |travis-develop|
    * - package
      - | |version| |wheel| |supported-versions| |supported-implementations|
        | |commits-since|
.. |docs| image:: https://readthedocs.org/projects/2019sp-pset-5-0-one/badge/?style=flat
    :target: https://readthedocs.org/projects/2019sp-pset-5-0-one
    :alt: Documentation Status

.. |travis-master| image:: https://travis-ci.com/csci-e-29/2019sp-pset-5-0-one.svg?token=LxQdQDY1ptAKysCL7cwC&branch=master
    :alt: Travis-CI Build Status
    :target: https://travis-ci.com/csci-e-29/2019sp-pset-5-0-one/branches

.. |travis-develop| image:: https://travis-ci.com/csci-e-29/2019sp-pset-5-0-one.svg?token=LxQdQDY1ptAKysCL7cwC&branch=develop
    :alt: Travis-CI Build Status
    :target: https://travis-ci.com/csci-e-29/2019sp-pset-5-0-one/branches

.. |appveyor| image:: https://ci.appveyor.com/api/projects/status/github/csci-e-29/2019sp-pset-5-0-one?branch=master&svg=true
    :alt: AppVeyor Build Status
    :target: https://ci.appveyor.com/project/csci-e-29/2019sp-pset-5-0-one

.. |version| image:: https://img.shields.io/pypi/v/pset-5.svg
    :alt: PyPI Package latest release
    :target: https://pypi.org/project/pset-5

.. |commits-since| image:: https://img.shields.io/github/commits-since/csci-e-29/2019sp-pset-5-0-one/v0.0.0.svg
    :alt: Commits since latest release
    :target: https://github.com/csci-e-29/2019sp-pset-5-0-one/compare/v0.0.0...master

.. |wheel| image:: https://img.shields.io/pypi/wheel/pset-5.svg
    :alt: PyPI Wheel
    :target: https://pypi.org/project/pset-5

.. |supported-versions| image:: https://img.shields.io/pypi/pyversions/pset-5.svg
    :alt: Supported versions
    :target: https://pypi.org/project/pset-5

.. |supported-implementations| image:: https://img.shields.io/pypi/implementation/pset-5.svg
    :alt: Supported implementations
    :target: https://pypi.org/project/pset-5


.. end-badges

CSCI E-29 Pset 5

* Free software: BSD 2-Clause License

Installation
============

::

    pip install pset-5

Documentation
=============


https://2019sp-pset-5-0-one.readthedocs.io/


Development
===========

To run the all tests run::

    tox

Note, to combine the coverage data from all the tox environments run:

.. list-table::
    :widths: 10 90
    :stub-columns: 1

    - - Windows
      - ::

            set PYTEST_ADDOPTS=--cov-append
            tox

    - - Other
      - ::

            PYTEST_ADDOPTS=--cov-append tox
