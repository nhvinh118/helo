""" PSET1 Main Function
	Entry Point of PSET1
"""
from .hash_str import get_csci_salt, get_user_id, hash_str
from .load_data import load_vectors, load_words, load_data
from .io import atomic_write
import os
import pandas as pd


def get_user_hash(username, salt=None):
    """Reurns a hashed username with a given salt using sha256

	:param str or bytes username: username to hash

	:param str or bytes salt: string or bytes to add randomness to the hashing,defaults to ''.
	
    :rtype: str or bytes salt
    """
    salt = salt or get_csci_salt()
    return hash_str(username, salt=salt)


if __name__ == '__main__':
    """Main Entry
	
	First, get the user id based on given user name
	Then, open the data source and save as a parquet file
	Next from the parquet file, read and print the id 

    """
    #1 Get the user id 
    for user in ['gorlins', 'nhvinh118']:
        hashed_user = get_user_id(user)
        print("Id for {}: {}".format(user, hashed_user))

    #2. Load data retrieved from S3
 
    fileDir = os.path.dirname(os.path.realpath('__file__'))
    XLSfilename = os.path.join(fileDir, '/data/hashed.xlsx')
    XLSfilename = fileDir + '/data/hashed.xlsx'
    XLSdf = load_data(XLSfilename)

    #3. Save data as new parquet file
    PRQfilename = fileDir + '/data/hashed.parquet'
	# Copy from EXCEL to PARQUET
    try:
        with atomic_write(PRQfilename) as f:
            XLSdf.to_parquet(f)
        
    except FileNotFoundError as ferror:
        print (ferror)	

    #4. Retrieve the ID coumn and print
    PRQdf = pd.read_parquet(PRQfilename, engine='pyarrow')
    #print(PRQdf.shape)
    #print(PRQdf.ndim)
    #print(PRQdf.dtypes)
    #print(PRQdf.loc[PRQdf['hashed_id'] == '5322582d'])
    print(PRQdf.hashed_id)