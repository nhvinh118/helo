from contextlib import contextmanager
import os
import tempfile


@contextmanager
def atomic_write(to_file, mode='w', as_file=True, **kwargs):
    """Write a file atomically

    :param to_file: str or :class:`os.PathLike` target to write

    :param bool as_file:  if True, the yielded object is a :class:File.
        (eg, what you get with `open(...)`).  Otherwise, it will be the
        temporary file path string

    :param kwargs: anything else needed to open the file

    :raises: FileExistsError if target exists

    Example::

        with atomic_write("hello.txt") as f:
            f.write("world!")
	
	Notes: The following approach is suggested in: 
	http://stupidpythonideas.blogspot.com/2014/07/getting-atomic-writes-right.html
	I liked the blog's idea of maximizing the use of Python standard libraries 
	Unfortunately, I have not yet validated all the claims made in the libray.

    """
    datafile = to_file

	# Use standard Tempfile module to write to temporary file
	# The tempfile will be in the same directory as to_file to avoid error with replace()
    with open(datafile, 'w+'), tempfile.NamedTemporaryFile(
    	dir=os.path.dirname(datafile), delete=False) as fout:
        yield fout
	
    os.replace(fout.name, datafile)
