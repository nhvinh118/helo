import os
import hashlib

def get_csci_salt():
    """Returns the appropriate salt for CSCI E-29

    :rtype: bytes
    """
    read_csci_salt = os.environ.get('CSCI_SALT')
    return bytes(read_csci_salt,'utf-8')

def hash_str(some_val, salt=''):
    """Converts strings to hash digest

    :param str or bytes some_val: thing to hash

    :param str or bytes salt: string or bytes to add randomness to the hashing,
        defaults to ''.

    :rtype: bytes
    """
    
    hashed_msg = some_val + salt
    assert hashed_msg != None, "Empty string - Nothing to hash"
    if isinstance(hashed_msg, str):
        hashed_msg = hashlib.sha256(str.encode(hashed_msg))
    else:
        hashed_msg = hashlib.sha256(str.encode(hashed_msg.decode("utf-8")))
    return(hashed_msg.digest())


def get_user_id(username):
    salt = get_csci_salt()
    uname = bytes(username.lower(), 'utf-8')
    return hash_str(uname, salt=salt).hex()[:8]