import re


def ftokenize(text):
    """Tokenize a string, expand known contractions, if unknown contraction, take first half of word

    :param str text: the string of text to be tokenized

    :rtype: list
    """

    return re.findall("[A-Z\']{2,}(?![a-z])|[A-Z\'][a-z\']+(?=[A-Z])|[\']+",text)