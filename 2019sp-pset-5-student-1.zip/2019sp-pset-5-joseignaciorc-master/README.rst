========
Overview
========

.. start-badges

.. list-table::
    :stub-columns: 1


    * - tests
      - | |travis|

.. |travis|  image:: https://travis-ci.com/csci-e-29/2019sp-pset-5-joseignaciorc.svg?token=SZyzUVosspEDL61LxXDH&branch=master
    :target: https://travis-ci.com/csci-e-29/2019sp-pset-5-joseignaciorc


.. end-badges

Pset 5

* Free software: BSD 2-Clause License

Installation
============

::

    pip install pset-5

