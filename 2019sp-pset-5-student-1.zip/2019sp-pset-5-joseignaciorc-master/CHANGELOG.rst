
Changelog
=========

0.0.0 (2019-04-10)
------------------

* First release on PyPI.
