"""
Module that contains the command line app.

Why does this file exist, and why not put this in __main__?

  You might be tempted to import things from __main__ later, but that will cause
  problems: the code will get executed twice:

  - When you run `python -mpset_5` python will execute
    ``__main__.py`` as a script. That means there won't be any
    ``pset_5.__main__`` in ``sys.modules``.
  - When you import __main__ it will get executed again (as a module) because
    there's no ``pset_5.__main__`` in ``sys.modules``.

  Also see (1) from http://click.pocoo.org/5/setuptools/#setuptools-integration
"""
import argparse
from luigi import build
from pset_5.tasks import ByDecade, ByStars

parser = argparse.ArgumentParser(description='Command description.')
parser.add_argument("--full", help="use the entire dataset, instead of just a subset", action="store_true")


def main(args=None):
    args = parser.parse_args(args=args)

    by_stars_task = ByStars(subset=not args.full)
    by_decade_task = ByDecade(subset=not args.full)
    build([by_stars_task, by_decade_task], local_scheduler=True)

    by_decade_task.print_results()
    by_stars_task.print_results()
