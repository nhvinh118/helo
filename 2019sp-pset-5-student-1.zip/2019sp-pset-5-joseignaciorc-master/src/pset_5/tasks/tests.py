from unittest import TestCase
import dask.dataframe
import tempfile
import pandas as pd
from luigi import ExternalTask, LocalTarget, build
from os.path import join as j
import os
from pset_utils.luigi.dask.target import ParquetTarget, CSVTarget
from pset_5.tasks import CleanedReviews, YelpReviews, ByStars, ByDecade


class CleanedReviewsTests(TestCase):

    def test_clean_reviews(self):
        """We check that the CleanedReviews task indeed cleans the input"""

        reviews = pd.DataFrame(data=[['123456789x123456789x12', 'user1', 'b1', 2, '2017-10-14', 'text1', 0, 0, 0],
                                     ['123456789y123456789y12', 'user2', 'b2', 2, '2017-10-14', 'text2', 0, 0, 0],
                                     ['not a 20char id', 'user3', 'b3', 2, '2017-10-14', 'text3', 0, 0, 0],
                                     ['123456789z123456789z12', 'user4', 'b4', 2, '2017-10-14', 'text4', 0, 0, 0],
                                     ['123456789a123456789a12', None, 'b5', 2, '2017-10-14', 'text5', 0, 0, 0],
                                     ['123456789b123456789b12', None, 'b6', 2, '2017-10-14', 'text6', 0, 0, 0]
                                     ],
                               columns=['review_id', 'user_id', 'business_id', 'stars', 'date', 'text', 'useful',
                                        'funny', 'cool'])

        with tempfile.TemporaryDirectory() as tmp_dir:
            # First, we feed the Yelp task a small set of reviews, only three of them are valid
            os.mkdir(j(tmp_dir, "dir-in"))
            dask.dataframe.from_pandas(reviews, npartitions=2).to_csv(j(tmp_dir, "dir-in", ""), index=False)

            yelp = YelpReviews()
            yelp.INPUT_PATH = j(tmp_dir, "dir-in", "")

            # Then, we run the clean task (CleanedReviews)
            clean_task = CleanedReviews(subset=False)
            clean_task.OUTPUT_DIR = j(tmp_dir, "dir-clean", "")

            build([clean_task], local_scheduler=True)

            # Finally, we read the output of the clean task and verify that it is cleaned as expected
            cleaned_dataframe = dask.dataframe.read_parquet(clean_task.output().path)
            expected_clean_users = ['user1', 'user2', 'user4']
            dask_clean_users = list(cleaned_dataframe.user_id.compute())

            self.assertEqual(expected_clean_users, dask_clean_users)
            self.assertEqual(cleaned_dataframe.stars.dtype, 'int64')
            self.assertEqual(cleaned_dataframe.funny.dtype, 'int64')
            self.assertEqual(cleaned_dataframe.cool.dtype, 'int64')
            self.assertEqual(cleaned_dataframe.useful.dtype, 'int64')
            self.assertEqual(cleaned_dataframe.date.dtype, 'datetime64[ns]')


class ByStarsTest(TestCase):
    def test_by_stars(self):
        """We check that ByStars calculates correctly the mean length of the texts"""
        clean_reviews = pd.DataFrame(
            data=[['123456789x123456789x12', 'user1', 'b1', 1, '2017-10-14', 'txt456', 0, 0, 0],
                  ['123456789y123456789y12', 'user2', 'b2', 1, '2017-10-14', 'txt456', 0, 0, 0],
                  ['123456789z123456789z12', 'user3', 'b4', 1, '2017-10-14', 'txt45', 0, 0, 0],
                  ['123456789a123456789a12', 'user4', 'b5', 2, '2017-10-14', 'txt45', 0, 0, 0],
                  ['123456789b123456789b12', 'user5', 'b6', 2, '2017-10-14', 'txt45', 0, 0, 0],
                  ['123456789a123456789a12', 'user4', 'b5', 5, '2017-10-14', 'txt45678', 0, 0, 0],
                  ['123456789b123456789b12', 'user5', 'b6', 5, '2017-10-14', 'txt4567', 0, 0, 0],
                  ],
            columns=['review_id', 'user_id', 'business_id', 'stars', 'date', 'text', 'useful',
                     'funny', 'cool'])

        with tempfile.TemporaryDirectory() as tmp_dir:
            # First, we create some fake data for the ByStars task
            os.mkdir(j(tmp_dir, "dir-in"))
            dask.dataframe.from_pandas(clean_reviews, npartitions=2).to_parquet(j(tmp_dir, "dir-in", ""))

            class input_task(ExternalTask):
                def output(self):
                    return ParquetTarget(j(tmp_dir, "dir-in", ""), flag=False)

            # Then we run it
            by_stars = ByStars()
            by_stars.OUTPUT_DIR = tmp_dir
            by_stars.requires = input_task

            build([by_stars], local_scheduler=True)
            by_stars_ddf = dask.dataframe.read_parquet(by_stars.output().path)

            # Finally, we check that the means are correct
            self.assertEqual(by_stars_ddf.loc[by_stars_ddf.stars == 1].compute().iloc[0]['text_len_rounded'], 6)
            self.assertEqual(by_stars_ddf.loc[by_stars_ddf.stars == 5].compute().iloc[0]['text_len_rounded'], 8)

    def test_by_decade(self):
        """We check that ByDecade calculates correctly the mean length of the texts"""
        clean_reviews = pd.DataFrame(
            data=[['123456789x123456789x12', 'user1', 'b1', 1, '1990-10-14', 'txt456', 0, 0, 0],
                  ['123456789y123456789y12', 'user2', 'b2', 1, '1991-10-14', 'txt456', 0, 0, 0],
                  ['123456789z123456789z12', 'user3', 'b4', 1, '2017-10-14', 'txt45', 0, 0, 0],
                  ['123456789a123456789a12', 'user4', 'b5', 2, '2018-10-14', 'txt456', 0, 0, 0],
                  ['123456789b123456789b12', 'user5', 'b6', 2, '2019-10-14', 'txt45', 0, 0, 0],
                  ['123456789a123456789a12', 'user4', 'b5', 5, '2009-10-14', 'txt45678', 0, 0, 0],
                  ['123456789b123456789b12', 'user5', 'b6', 5, '2008-10-14', 'txt4567', 0, 0, 0],
                  ],
            columns=['review_id', 'user_id', 'business_id', 'stars', 'date', 'text', 'useful',
                     'funny', 'cool'])

        with tempfile.TemporaryDirectory() as tmp_dir:
            # First, we create some fake data for the ByStars task
            os.mkdir(j(tmp_dir, "dir-in"))
            df = dask.dataframe.from_pandas(clean_reviews, npartitions=2, )
            df['date'] = df['date'].astype('datetime64[ns]')
            df.to_parquet(j(tmp_dir, "dir-in", ""))

            class input_task(ExternalTask):
                def output(self):
                    return ParquetTarget(j(tmp_dir, "dir-in", ""), flag=False)

            # Then we run it
            by_decade = ByDecade()
            by_decade.OUTPUT_DIR = tmp_dir
            by_decade.requires = input_task

            build([by_decade], local_scheduler=True)
            by_decade = dask.dataframe.read_parquet(by_decade.output().path)

            # Finally, we check that the means are correct
            self.assertEqual(by_decade.loc[by_decade.decade == 1990].compute().iloc[0]['text_len_rounded'], 6)
            self.assertEqual(by_decade.loc[by_decade.decade == 2000].compute().iloc[0]['text_len_rounded'], 8)
            self.assertEqual(by_decade.loc[by_decade.decade == 2010].compute().iloc[0]['text_len_rounded'], 5)
