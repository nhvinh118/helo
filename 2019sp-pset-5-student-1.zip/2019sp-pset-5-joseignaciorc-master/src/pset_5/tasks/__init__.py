import os
from luigi import Task, ExternalTask, BoolParameter, build
from pset_utils.luigi.dask.target import CSVTarget, ParquetTarget
from pset_utils.luigi.task import TargetOutput
import dask.dataframe as ddf


class YelpReviews(ExternalTask):
    INPUT_PATH = "s3://cscie29-data/pset5/yelp_data/"

    def output(self):
        return CSVTarget(self.INPUT_PATH, flag=False, glob="*")


class CleanedReviews(Task):
    """This task cleans the Yelp reviews, removing the malformed rows and correcting the dtypes of some columns"""
    subset = BoolParameter(default=True)

    # Output should be a local ParquetTarget in ./data, ideally a salted output,
    # and with the subset parameter either reflected via salted output or
    # as part of the directory structure

    OUTPUT_DIR = "./data/"

    def requires(self):
        return YelpReviews()

    def output(self):
        return TargetOutput(basedir=self.OUTPUT_DIR, target_class=ParquetTarget, ext=os.sep)(self)

    def run(self):
        numcols = ["funny", "cool", "useful", "stars"]
        dsk: ddf = self.input().read_dask(dtype={col: 'float64' for col in numcols}, parse_dates=['date'])

        if self.subset:
            dsk = dsk.get_partition(0)

        dsk[numcols] = dsk[numcols].fillna(0)
        dsk[numcols] = dsk[numcols].astype('int64')

        dsk = dsk.loc[(dsk['review_id'].str.len() == 22) & (dsk['user_id'].notnull())]
        dsk = dsk.set_index('review_id')

        self.output().write_dask(dsk, compression='gzip')


class BySomething(Task):
    """Abstract class, inherited by 'ByDecade' and by 'ByStars'"""
    OUTPUT_DIR = "./data/"
    subset = BoolParameter(default=True)

    def requires(self):
        return CleanedReviews(self.subset)

    def output(self):
        return TargetOutput(basedir=self.OUTPUT_DIR, target_class=ParquetTarget, ext=os.sep)(self)

    def print_results(self):
        print(self.output().read_dask().compute())

    def run(self):
        raise NotImplementedError("BySomething is abstract")


class ByDecade(BySomething):
    """Luigi task that gets the mean review length by decade"""
    def run(self):
        df = self.input().read_dask()[['date', 'text']]
        df['text_len'] = df['text'].str.len()
        df['decade'] = df['date'].dt.year - df['date'].dt.year % 10
        means = df.groupby('decade').mean()[['text_len']]
        means['text_len_rounded'] = means['text_len'].round().astype('int64')
        means['decade'] = means.index
        self.output().write_dask(means[['decade', 'text_len_rounded']], compression='gzip')



class ByStars(BySomething):
    """Luigi task that gets the mean review length by number of stars"""
    def run(self):
        df = self.input().read_dask()[['stars', 'text']]
        df['text_len'] = df['text'].str.len()
        means = df.groupby('stars').mean()[['text_len']]
        means['text_len_rounded'] = means['text_len'].round().astype('int64')
        means['stars'] = means.index
        self.output().write_dask(means[['stars', 'text_len_rounded']], compression='gzip')

