========
Overview
========

.. start-badges

.. list-table::
    :stub-columns: 1

    * - docs
      - |docs|
    * - tests
      - | master |travis-master|
        | develop |travis-develop|
    * - package
      - | |version| |wheel| |supported-versions| |supported-implementations|
        | |commits-since|
.. |docs| image:: https://readthedocs.org/projects/2019sp-pset-utils-0-one/badge/?style=flat
    :target: https://readthedocs.org/projects/2019sp-pset-utils-0-one
    :alt: Documentation Status

.. |travis-master| image:: https://travis-ci.com/csci-e-29/2019sp-pset-utils-0-one.svg?token=LxQdQDY1ptAKysCL7cwC&branch=master
    :alt: Travis-CI Build Status
    :target: https://travis-ci.com/csci-e-29/2019sp-pset-utils-0-one

.. |travis-develop| image:: https://travis-ci.com/csci-e-29/2019sp-pset-utils-0-one.svg?token=LxQdQDY1ptAKysCL7cwC&branch=develop
    :alt: Travis-CI Build Status
    :target: https://github.com/csci-e-29/2019sp-pset-utils-0-one/tree/develop

.. |version| image:: https://img.shields.io/pypi/v/pset-utils.svg
    :alt: PyPI Package latest release
    :target: https://pypi.org/project/pset-utils

.. |commits-since| image:: https://img.shields.io/github/commits-since/csci-e-29/2019sp-pset-utils-0-one/v0.0.0.svg
    :alt: Commits since latest release
    :target: https://github.com/csci-e-29/2019sp-pset-utils-0-one/compare/v0.0.0...master

.. |wheel| image:: https://img.shields.io/pypi/wheel/pset-utils.svg
    :alt: PyPI Wheel
    :target: https://pypi.org/project/pset-utils

.. |supported-versions| image:: https://img.shields.io/pypi/pyversions/pset-utils.svg
    :alt: Supported versions
    :target: https://pypi.org/project/pset-utils

.. |supported-implementations| image:: https://img.shields.io/pypi/implementation/pset-utils.svg
    :alt: Supported implementations
    :target: https://pypi.org/project/pset-utils


.. end-badges

CSCI E-29 Pset Utils

* Free software: BSD 2-Clause License

Installation
============

::

    pip install pset-utils

Documentation
=============


https://2019sp-pset-utils-0-one.readthedocs.io/


Development
===========

To run the all tests run::

    tox

Note, to combine the coverage data from all the tox environments run:

.. list-table::
    :widths: 10 90
    :stub-columns: 1

    - - Windows
      - ::

            set PYTEST_ADDOPTS=--cov-append
            tox

    - - Other
      - ::

            PYTEST_ADDOPTS=--cov-append tox
