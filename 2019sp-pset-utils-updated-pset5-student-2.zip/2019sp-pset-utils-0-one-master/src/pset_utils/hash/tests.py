#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `pset_utils.hash` package."""

import os
from unittest import TestCase

from ..hash import hash_str
from ..hash import get_user_id


class HashTests(TestCase):

    def test_basic(self):
        self.assertEqual(
            hash_str('world!', salt='hello, ').hex()[:6], '68e656')

    def test_bytes_input(self):
        self.assertEqual(
            hash_str(b'world!', salt='hello, ').hex()[:6], '68e656')

    def test_env_salt(self):
        """Tests CSCI_SALT from Environment against a known string."""

        salt_string = "Hello World!"

        try:
            try:
                orig_salt_env = os.environ['CSCI_SALT']
            except KeyError:
                orig_salt_env = None

            # turns the string into a hex string, ready to be interpreted by bytes.fromhex()
            # "Hello World!" would become "48656C6C6F20576F726C6421"
            os.environ['CSCI_SALT'] = salt_string.encode().hex()

            env_salt_result = get_user_id("test_user")
            manual_result = hash_str("test_user".lower(), salt=salt_string).hex()[:8]

            self.assertEqual(env_salt_result, manual_result)

        finally:
            if orig_salt_env == None:
                os.environ.pop('CSCI_SALT')
            else:
                os.environ['CSCI_SALT'] = orig_salt_env
