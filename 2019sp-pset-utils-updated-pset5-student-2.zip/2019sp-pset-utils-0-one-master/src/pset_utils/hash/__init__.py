import hashlib
import os

def get_csci_salt():
    """Returns the appropriate salt for CSCI E-29

    Returns:
        bytes of CSCI_SALT interpreted as hex
    """

    try:
        # get CSCI_SALT from envrionment and interpret it as hex string
        salt = bytes.fromhex(os.environ['CSCI_SALT'])
    except KeyError:
        salt = bytes.fromhex("")

    return salt

def hash_str(some_val, salt=''):
    """Converts strings to hash digest

    See: https://en.wikipedia.org/wiki/Salt_(cryptography)

    Args:
        some_val: A str or bytes containing the item to be hashed
        salt: str or bytes containing the salt, defaults to ""

    Returns:
        bytes containing the hash digest
    """

    h = hashlib.sha256()

    try:
        salt = salt.encode()
    except AttributeError:
        pass

    h.update(salt)


    try:
        some_val = some_val.encode()
    except AttributeError:
        pass

    h.update(some_val)

    return h.digest()



def get_user_id(username):
    """ Gets the hash of a user ID together with the CSCI_SALT.

    Args:
        username: str

    Returns:
        str of the hash digest
    """

    salt = get_csci_salt()
    return hash_str(username.lower(), salt=salt).hex()[:8]
