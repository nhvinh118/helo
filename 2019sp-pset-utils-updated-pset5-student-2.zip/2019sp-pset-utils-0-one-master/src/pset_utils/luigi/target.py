from luigi.local_target import LocalTarget, atomic_file

from contextlib import contextmanager
import pathlib
import random


class suffix_preserving_atomic_file(atomic_file):
    """ This atomic file provider uses temp file name that preserves the target file suffix.

    Further details see atomic_file.
    """
    def generate_tmp_path(self, path):
        """ This generates a temp file name for atomic writing.

        The generated temp file name is in the same path as the target. The suffix also matches
        that of the target. This method overrides the one in the super class.

        Args:
            path: str, the path of the target file

        Returns:
            A string, path of a new temp file with suffix that matches the target
        """
        base_path = pathlib.Path(path)
        base_dir = base_path.absolute().parent
        base_name = base_path.name
        new_prefix = 'luigi-tmp-%09d-' % random.randrange(0, 1e10)
        return str(base_dir.joinpath(new_prefix + base_name))


class BaseAtomicProviderLocalTarget(LocalTarget):
    """ This is Luigi LocalTarget. The atomic file writing logic can changed via composition.


    """
    # Allow some composability of atomic handling
    atomic_provider = atomic_file

    def open(self, mode='r'):
        """ O

        This method overrides the one in the super class. The main change is that it
        uses a composible atomic_provider, so the atomic file logic can be changed by subclassing
        this class.
        The rest of the functionality is done by calling super().open().

        Further details see LocalTarget.

        Args:
            mode: str, file access mode

        Returns:
            A file like object.
        """
        rwmode = mode.replace('b', '').replace('t', '')
        if rwmode == 'w':
            self.makedirs()
            return self.format.pipe_writer(self.atomic_provider(self.path))
        else:
            return super().open(mode)

    @contextmanager
    def temporary_path(self):
        """ A context manager that yields a temp filename, implementing atomic writing.

        This method overrides the one in the super class. The main change is that it
        uses a composible atomic_provider, so the atomic file logic can be changed by subclassing
        this class.

        Further details see LocalTarget.

        Yields:
            A string, path of a temporary file
        """
        # NB: unclear why LocalTarget doesn't use atomic_file in its implementation
        self.makedirs()
        with self.atomic_provider(self.path) as af:
            yield af.tmp_path


class SuffixPreservingLocalTarget(BaseAtomicProviderLocalTarget):
    """ This is a Luigi LocalTarget that writes atomically and uses temp file names that matches the target suffix.

    This class uses suffix_preserving_atomic_file via composition.

    Further details see BaseAtomicProviderLocalTarget.
    """
    atomic_provider = suffix_preserving_atomic_file

