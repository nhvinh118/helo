#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `pset_utils.luigi` package."""

import os
from tempfile import TemporaryDirectory
from unittest import TestCase
import sys

from .tasks import CopyLocally
from .output import LocalTargetOutput
from .requirement import Requires, Requirement
from luigi import Task, Parameter, build
from luigi.format import Nop, Text
from .target import SuffixPreservingLocalTarget
import pathlib

class FakeFileFailure(IOError):
    pass

class HelperTask(Task):
    """ Helps creates LocalTarget used as inputs to test tasks. """
    path = Parameter(default="")

    def output(self):
        return SuffixPreservingLocalTarget(self.path)


class LuigiAtomicTests(TestCase):

    def test_atomic_write(self):
        """Ensure target file exists after being written successfully"""

        class AtomicTestTask(HelperTask):
            def run(self):
                with self.output().open('w') as f:
                    tmp_filename = f.name
                    f.write('asdf')

                assert not os.path.exists(tmp_filename)
                assert os.path.exists(self.path)


        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')
            assert build([AtomicTestTask(path=fp)], local_scheduler=True)
            with open(fp) as f:
                self.assertEqual(f.read(), 'asdf')



    def test_atomic_failure(self):
        """Ensure that target file does not exist after failure during write"""

        class AtomicTestTask(HelperTask):
            def run(self):
                try:
                    with self.output().open('w') as f:
                        tmp_filename = f.name
                        raise FakeFileFailure()
                except FakeFileFailure:
                    pass

                assert not os.path.exists(self.path)


        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')
            assert build([AtomicTestTask(path=fp)], local_scheduler=True)
            if sys.platform != 'win32':
                assert len(os.listdir(tmp)) == 0


    def test_atomic_write_temporary_path(self):
        """This tests temporary_path().
           Ensure a string is returned and points to a closed file that exists.
           This file is ready to be written to inside the context."""

        class AtomicTestTask(HelperTask):
            def run(self):
                with self.output().temporary_path() as f:
                    assert not os.path.exists(self.path)
                    assert isinstance(f, str)
                    assert os.path.exists(f)

                    with open(f, 'w') as tmpfile:
                        tmpfile.write('asdf')

                assert not os.path.exists(f)
                assert os.path.exists(self.path)


        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')
            assert build([AtomicTestTask(path=fp)], local_scheduler=True)

            with open(fp) as f:
                self.assertEqual(f.read(), 'asdf')



    def test_atomic_write_same_directory(self):
        """Ensures that the temp file and the target are in the same directory.
           This is maximizes the chance of them being on the same file system."""

        class AtomicTestTask(HelperTask):
            def run(self):
                with self.output().open('w') as f:
                    temp_file_directory = pathlib.Path(f.name).absolute().parent
                    target_file_directory = pathlib.Path(self.path).absolute().parent
                    assert temp_file_directory == target_file_directory


        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')
            assert build([AtomicTestTask(path=fp)], local_scheduler=True)



    def test_atomic_write_extension(self):
        """Ensures that temp file extension is the same as the target."""

        class AtomicTestTask(HelperTask):
            def run(self):
                with self.output().open('w') as f:
                    temp_file_extension = ".".join(f.name.split('.')[1:])
                    target_file_extension = ".".join(self.path.split('.')[1:])
                    assert temp_file_extension == target_file_extension


        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.tar.gz')
            assert build([AtomicTestTask(path=fp)], local_scheduler=True)



    def test_atomic_write_new_temp_file(self):
        """Ensures that the temp file name is different if the process fails and then
           retries."""

        class AtomicTestTask(HelperTask):
            def run(self):
                try:
                    with self.output().open('w') as f:
                        first_temp_file_name = f.name
                        raise FakeFileFailure
                except FakeFileFailure:
                    pass

                try:
                    with self.output().open('w') as f:
                        second_temp_file_name = f.name
                        raise FakeFileFailure
                except FakeFileFailure:
                    pass

                assert first_temp_file_name != second_temp_file_name


        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')
            assert build([AtomicTestTask(path=fp)], local_scheduler=True)


class LuigiCopyLocallyTests(TestCase):

    def test_copy_locally_target_filename(self):
        """Ensures that the destination file name is correct."""

        class CopyTestTask(CopyLocally, HelperTask):
            out_path = Parameter(default="")

            input_file = Requirement(HelperTask)

            output = LocalTargetOutput('{task.out_path}', format=Text)


        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'copy_input.txt')
            ofp = os.path.join(tmp, 'copy_output.txt')

            with open(ifp, 'w') as f:
                f.write('asdf')

            assert build([CopyTestTask(path=ifp, out_path=ofp)], local_scheduler=True)

            assert os.path.exists(ofp)


    def test_copy_locally_multiple_requirements(self):
        """Ensures that the copy task fails when multiple input targets (requirement tasks)
         are specified."""

        class CopyTestTask(CopyLocally, HelperTask):
            out_path = Parameter(default="")

            input_file1 = Requirement(HelperTask)
            input_file2 = Requirement(HelperTask)

            output = LocalTargetOutput('{task.out_path}', format=Text)


        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'copy_input.txt')
            ofp = os.path.join(tmp, 'copy_output.txt')

            # here we "assert not" since we expect errors
            assert not build([CopyTestTask(path=ifp, out_path=ofp)], local_scheduler=True)

            assert not os.path.exists(ofp)


    def test_copy_locally_no_requirements(self):
        """Ensures that the copy task fails when no input targets (requirement tasks)
         are specified."""

        class CopyTestTask(CopyLocally, HelperTask):
            out_path = Parameter(default="")

            output = LocalTargetOutput('{task.out_path}', format=Text)


        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'copy_input.txt')
            ofp = os.path.join(tmp, 'copy_output.txt')

            # here we "assert not" since we expect errors
            assert not build([CopyTestTask(path=ifp, out_path=ofp)], local_scheduler=True)

            assert not os.path.exists(ofp)



    def test_copy_locally_text_data_correctness(self):
        """Ensures that the copied file (in text mode) has the correct content."""
        class CopyTestTask(CopyLocally, HelperTask):
            out_path = Parameter(default="")

            input_file = Requirement(HelperTask)

            output = LocalTargetOutput('{task.out_path}', format=Text)


        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'copy_input.txt')
            ofp = os.path.join(tmp, 'copy_output.txt')

            with open(ifp, 'w') as f:
                f.write('asdf')

            assert build([CopyTestTask(path=ifp, out_path=ofp)], local_scheduler=True)

            with open(ofp, 'r') as f1:
                self.assertEqual(f1.read(), 'asdf')



    def test_copy_locally_dependency_input_changed(self):
        """Ensures that the if the destination exists, the Copy task does nothing and leaves the
           output untouched."""

        class CopyTestTask(CopyLocally, HelperTask):
            out_path = Parameter(default="")

            input_file = Requirement(HelperTask)

            output = LocalTargetOutput('{task.out_path}', format=Text)


        with TemporaryDirectory() as tmp:
            # first, we copy a file to the destination
            ifp = os.path.join(tmp, 'copy_input.txt')
            ofp = os.path.join(tmp, 'copy_output.txt')

            with open(ifp, 'w') as f:
                f.write('asdf')

            assert build([CopyTestTask(path=ifp, out_path=ofp)], local_scheduler=True)

            with open(ofp, 'r') as f1:
                self.assertEqual(f1.read(), 'asdf')

            # now we change the input file and schedule the copy task again,
            # and then check that the Copy task's output is unchanged
            with open(ifp, 'w') as f:
                f.write('1234')

            assert build([CopyTestTask(path=ifp, out_path=ofp)], local_scheduler=True)

            with open(ofp, 'r') as f1:
                self.assertEqual(f1.read(), 'asdf')


    def test_copy_locally_dependency_no_input(self):
        """Ensures that if the destination file exists, the Copy task does not fail even if
           input is unavailable. The original file at destination should be unchanged."""

        class CopyTestTask(CopyLocally, HelperTask):
            out_path = Parameter(default="")

            input_file = Requirement(HelperTask)

            output = LocalTargetOutput('{task.out_path}', format=Text)


        with TemporaryDirectory() as tmp:
            # first, we copy a file to the destination
            ifp = os.path.join(tmp, 'copy_input.txt')
            ofp = os.path.join(tmp, 'copy_output.txt')

            with open(ifp, 'w') as f:
                f.write('asdf')

            assert build([CopyTestTask(path=ifp, out_path=ofp)], local_scheduler=True)

            with open(ofp, 'r') as f1:
                self.assertEqual(f1.read(), 'asdf')

            # now we remove the input file and schedule the copy task again,
            # and then check that the Copy task's output is unchanged
            os.unlink(ifp)

            assert build([CopyTestTask(path=ifp, out_path=ofp)], local_scheduler=True)

            with open(ofp, 'r') as f1:
                self.assertEqual(f1.read(), 'asdf')


    def test_copy_locally_binary_data_correctness(self):
        """Ensures that the copied file (in binary mode) has the correct content."""

        class BinaryHelperTask(HelperTask):
            def output(self):
                return SuffixPreservingLocalTarget(self.path, format=Nop)

        class CopyTestTask(CopyLocally, HelperTask):
            out_path = Parameter(default="")

            input_file = Requirement(BinaryHelperTask)

            output = LocalTargetOutput('{task.out_path}', format=Nop)


        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'copy_input.txt')
            ofp = os.path.join(tmp, 'copy_output.txt')

            with open(ifp, 'wb') as f:
                f.write(b'asdf')

            assert build([CopyTestTask(path=ifp, out_path=ofp)], local_scheduler=True)

            with open(ofp, 'rb') as f1:
                self.assertEqual(f1.read(), b'asdf')



    def test_copy_locally_is_atomic(self):
        """Ensures that the CopyLocally is atomic. If the copy fails, the target file
           does not exist.

           Here we make use of the fact that when we specify an input as Text (format=None), and
           an output as binary (format=Nop), we will result in an error during the copy.

           We check that the target file is not created in this case."""

        class CopyTestTask(CopyLocally):
            path = Parameter(default="")
            out_path = Parameter(default="")

            # The HelperTask defaults to a Text mode output target.
            input_file = Requirement(HelperTask)

            output = LocalTargetOutput('{task.out_path}', format=Nop)

        # Need to wrap this in a try/except block because
        # in Windows, there is a permission error during removal of
        # the tmp file due to the "zombie" luigi process and Windows'
        # locking mechanism.
        try:
            with TemporaryDirectory() as tmp:
                ifp = os.path.join(tmp, 'copy_input.txt')
                ofp = os.path.join(tmp, 'copy_output.txt')

                with open(ifp, 'wb') as f:
                    f.write(b'\x00asdf')

                # Here we "assert not" the build result to be True because we expect
                # errors during the copy task.
                assert not build([CopyTestTask(path=ifp, out_path=ofp)], local_scheduler=True)

                output_exists = os.path.exists(ofp)
        except PermissionError:
            pass

        assert output_exists == False

