from luigi import Task
from luigi.task import flatten
from .requirement import Requires, Requirement
from .output import LocalTargetOutput

class CopyLocally(Task):
    """ Luigi Task to copy an input to a local target.

    This class is meant to be subclassed. The subclass should compose the dependent task
    via a Requirement. This class supports copying from one input to one output target.
    The subclass can override the "output" attribute via composition to supply its own
    filename pattern template and format specification.
    """
    requires = Requires()
    output = LocalTargetOutput()

    def run(self):
        """ Called by Luigi upon Task execution.

        This method copies input to output target.

        Raises:
            NotImplementedError if multiple input or output targets are encountered or
                if no input or output targets are specified.
        """
        input_target = flatten(self.input())
        if len(input_target) != 1:
            raise NotImplementedError("Exactly one input target is supported.")
        input_target = input_target[0]

        output_target = flatten(self.output())
        if len(output_target) != 1:
            raise NotImplementedError("Exactly one output target is supported.")
        output_target = output_target[0]

        with input_target.open('r') as input_file:
            with output_target.open('w') as output_file:
                output_file.write(input_file.read())
