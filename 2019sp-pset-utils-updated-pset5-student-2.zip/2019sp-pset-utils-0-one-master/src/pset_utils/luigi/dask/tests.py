#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `pset_utils.luigi.dask` package.
These tests also uses Requires, Requirements and TargetOutput from `pset_utils.luigi.task` and serve
as tests for these classes as well."""

import os
from tempfile import TemporaryDirectory
from unittest import TestCase

from ..task import TargetOutput, Requires, Requirement
from .target import CSVTarget, ParquetTarget

from luigi import Task, ExternalTask, Parameter, build
import pandas as pd
from dask.bytes.core import get_fs_token_paths
import dask.dataframe as dd


def make_df():
    """ Makes a pandas dataframe with dummy data. """
    return pd.DataFrame({"c1": [1, 2, 3], "c2": [4, 5, 6]})


def external_task_factory(target_cls, flag, use_glob=False):
    """ Factory method to create Luigi External Tasks to be used as input to tests. """
    class new_class(ExternalTask):
        """ Helps creates LocalTarget used as inputs to test tasks. """
        out_path = Parameter(default="")
        out_ext = Parameter(".csv")
        out_glob = Parameter("read_input.*")

        if use_glob:
            output = TargetOutput('{task.out_path}', ext='{task.out_ext}',
                                  target_class=target_cls, glob='{task.out_glob}', flag = flag)
        else:
            output = TargetOutput('{task.out_path}', ext='{task.out_ext}',
                                  target_class=target_cls, flag=flag)
    return new_class


def write_task_factory(dframe, write_opts, target_cls, flag='_SUCCESS', use_glob=False):
    """ Factory method to create Luigi Tasks for write tests. """
    class new_class(Task):
        """ Helps creates LocalTarget used as inputs to test tasks. """
        out_path = Parameter(default="")
        out_ext = Parameter(".csv")
        out_glob = Parameter("read_input.*")

        if use_glob:
            output = TargetOutput('{task.out_path}', ext='{task.out_ext}',
                                  target_class=target_cls, glob='{task.out_glob}', flag = flag)
        else:
            output = TargetOutput('{task.out_path}', ext='{task.out_ext}',
                                  target_class=target_cls, flag=flag)

        def run(self):
            self.output().write_dask(dframe, **write_opts)

    return new_class


class HelperTaskBase(Task):
    out_path = Parameter(default="")
    out_ext = Parameter(".csv")
    requires = Requires()
    result = None

    def run(self):
        dsk = self.input()['input_file'].read_dask()
        self.__class__.result = dsk.compute()
        assert len(self.__class__.result) == 3


class DaskTargetsReadTests(TestCase):
    """ These are test cases for dask target reading. """

    def test_read_csv_no_flag(self):
        """Ensures that CSV files can be read when flag is None.
        We also compare the results with the generated dataframe to ensure correct content."""

        # create an Luigi External Task as input to the test
        external_task = external_task_factory(CSVTarget, None, True)

        class ReadTestTask(HelperTaskBase):
            input_file = Requirement(external_task)

        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'read_input.0.csv')

            # create dummy input file
            df = make_df()
            df.to_csv(ifp, index=False)

            assert build([ReadTestTask(out_path=tmp)], local_scheduler=True)
            # check content correctness
            assert ReadTestTask.result.equals(df)


    def test_read_parquet_no_flag(self):
        """Ensures that Parquet files can be read when flag is None.
        We also compare the results with the generated dataframe to ensure correct content."""

        # create an Luigi External Task as input to the test
        external_task = external_task_factory(ParquetTarget, None)

        class ReadTestTask(HelperTaskBase):
            input_file = Requirement(external_task)

        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'a')

            # create dummy input file
            tmp_with_sep = tmp + get_fs_token_paths(tmp)[0].sep
            df = make_df()
            dd.from_pandas(df, npartitions=1).to_parquet(ifp, compression='gzip')

            assert build([ReadTestTask(out_path=tmp_with_sep, out_ext="a")], local_scheduler=True)
            # check content correctness
            assert ReadTestTask.result.equals(df)

    def test_read_csv_with_flag_fail(self):
        """Ensures that CSV files CANNOT be read without a flag if a flag is specified."""

        # create an Luigi External Task as input to the test
        external_task = external_task_factory(CSVTarget, '_SUCCESS', True)

        class ReadTestTask(HelperTaskBase):
            input_file = Requirement(external_task)

            def run(self):
                # throws exception if the task is run!
                raise AssertionError

        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'read_input.0.csv')

            # create dummy input file
            df = make_df()
            df.to_csv(ifp, index=False)

            assert build([ReadTestTask(out_path=tmp)], local_scheduler=True)

    def test_read_parquet_with_flag_fail(self):
        """Ensures that Parquet files CANNOT be read without a flag if a flag is specified."""

        # create an Luigi External Task as input to the test
        external_task = external_task_factory(ParquetTarget, '_SUCCESS')

        class ReadTestTask(HelperTaskBase):
            input_file = Requirement(external_task)

            def run(self):
                # throws exception if the task is run!
                raise AssertionError

        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'a')

            # create dummy input file
            tmp_with_sep = tmp + get_fs_token_paths(tmp)[0].sep
            df = make_df()
            dd.from_pandas(df, npartitions=1).to_parquet(ifp, compression='gzip')

            assert build([ReadTestTask(out_path=tmp_with_sep, out_ext="a")], local_scheduler=True)
            assert ReadTestTask.result == None

    def test_read_csv_with_flag_success(self):
        """Ensures that CSV files can be read when a flag is set and that it is present in the directory."""

        # create an Luigi External Task as input to the test
        external_task = external_task_factory(CSVTarget, '_SUCCESS', True)

        class ReadTestTask(HelperTaskBase):
            input_file = Requirement(external_task)


        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'read_input.0.csv')

            # create dummy input file
            df = make_df()
            df.to_csv(ifp, index=False)
            with open(os.path.join(tmp, '_SUCCESS'), 'wb') as f:
                f.write(b'abc')

            assert build([ReadTestTask(out_path=tmp)], local_scheduler=True)
            assert ReadTestTask.result.equals(df)

    def test_read_parquet_with_flag_success(self):
        """Ensures that Parquet files can be read when a flag is set and that it is present in the directory."""

        # create an Luigi External Task as input to the test
        external_task = external_task_factory(ParquetTarget, '_SUCCESS')

        class ReadTestTask(HelperTaskBase):
            input_file = Requirement(external_task)


        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'a')

            # create dummy input file
            tmp_with_sep = tmp + get_fs_token_paths(tmp)[0].sep
            df = make_df()
            dd.from_pandas(df, npartitions=1).to_parquet(ifp, compression='gzip')
            with open(os.path.join(ifp, '_SUCCESS'), 'wb') as f:
                f.write(b'abc')

            assert build([ReadTestTask(out_path=tmp_with_sep, out_ext="a")], local_scheduler=True)
            assert ReadTestTask.result.equals(df)


class DaskTargetsWriteTests(TestCase):
    """ These are test cases for dask target writing. """

    def test_write_csv(self):
        """Ensures that CSV files can be written correctly by reading back and comparing content.
        We also tests if parent directory can be automatically created.
        Additionally, we test that the handling of glob and ext is correct."""

        with TemporaryDirectory() as tmp:
            # we deliberatly add one more level inside the temp directory to test path creation
            ifp = os.path.join(tmp, 'a', 'read_input.0.csv')

            # create dummy input file
            df = make_df()
            dask_df = dd.from_pandas(df, npartitions=1)

            write_task = write_task_factory(dask_df, {'index': False}, CSVTarget, use_glob=True)

            assert build([write_task(out_path=os.path.join(tmp, 'a'))], local_scheduler=True)

            new_df = dd.read_csv(ifp).compute()
            # compare the original dataframe and the one that is read back from disk
            assert new_df.equals(df)
            # make sure that the flag file is written
            assert os.path.exists(os.path.join(os.path.join(tmp, 'a'), '_SUCCESS'))


    def test_write_parquet(self):
        """Ensures that Parquet files can be written correctly by reading back and comparing content.
        We also test if parent directory can be automatically created.
        Additionally, we test that the handling of glob and ext is correct."""

        with TemporaryDirectory() as tmp:
            # we deliberatly add one more level inside the temp directory to test path creation
            ifp = os.path.join(tmp, 'a') + get_fs_token_paths(tmp)[0].sep

            # create dummy input file
            df = make_df()
            dask_df = dd.from_pandas(df, npartitions=1)

            tmp_with_sep = tmp + get_fs_token_paths(tmp)[0].sep
            write_task = write_task_factory(dask_df, {'compression': 'gzip'}, ParquetTarget)

            assert build([write_task(out_path=tmp_with_sep, out_ext="a")], local_scheduler=True)

            new_df = dd.read_parquet(ifp).compute()
            # compare the original dataframe and the one that is read back from disk
            assert new_df.equals(df)
            # make sure that the flag file is written
            assert os.path.exists(os.path.join(ifp, '_SUCCESS'))

    def test_write_csv_atomic(self):
        """Ensures that CSV write is atomic."""

        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'read_input.0.csv')

            # create dummy data frame
            df = make_df()
            dask_df = dd.from_pandas(df, npartitions=1)

            # here were pass an invalid option to force exception
            write_task = write_task_factory(dask_df, {'invalid_opt': False}, CSVTarget, use_glob=True)

            # here we expect it to fail, so we "assert not"
            assert not build([write_task(out_path=tmp)], local_scheduler=True)
            # make sure the failure is atomic
            assert not os.path.exists(os.path.join(tmp, '_SUCCESS'))


    def test_write_parquet_atomic(self):
        """Ensures that Parquet write is atomic."""

        with TemporaryDirectory() as tmp:
            ifp = os.path.join(tmp, 'a') + get_fs_token_paths(tmp)[0].sep

            # create dummy data frame
            df = make_df()
            dask_df = dd.from_pandas(df, npartitions=1)

            tmp_with_sep = tmp + get_fs_token_paths(tmp)[0].sep
            # here were pass an invalid option to force exception
            write_task = write_task_factory(dask_df, {'invalid_opt': 'gzip'}, ParquetTarget)

            # here we expect it to fail, so we "assert not"
            assert not build([write_task(out_path=tmp_with_sep, out_ext="a")], local_scheduler=True)
            # make sure the failure is atomic
            assert not os.path.exists(os.path.join(ifp, '_SUCCESS'))
