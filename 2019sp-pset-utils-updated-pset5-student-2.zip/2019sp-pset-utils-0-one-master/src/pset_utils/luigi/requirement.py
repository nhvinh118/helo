# The following two imports are used because the Requires and Requirement descriptors
# were originally implemented during Pset 4 here (requirement.py). Now these descriptors
# are moved to task.py as per specifications of Pset 5.
#
# The imports here maintain backward compatibility and allow the following statement
# to continue to work:
#     from pset_utils.luigi.requirement import Requirement, Requires

from .task import Requirement
from .task import Requires
