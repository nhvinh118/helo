from .target import SuffixPreservingLocalTarget

class LocalTargetOutput:
    """ Descriptor for Luigi Task output composition.

    This class implements the Python descriptor protocol. This class can be used to compose Luigi
    Task output.
    """
    def __init__(self, file_pattern='{task.__class__.__name__}', cls=SuffixPreservingLocalTarget,
                 format=None):
        """ Constructor of LocalTargetOuput descriptor.

        The descriptor is to be instantiated during host class definition. This descriptor should be
        assigned to the host class's "output" attribute.

        Args:
            file_pattern: str, a template to be evaluated when the "output" attribute is accessed
                via an instance of the host class.
            cls: a Luigi LocalTarget class or subclass; defaults to SuffixPreservingLocalTarget.
            format: a Luigi.format, defaults to None, which lets Luigi pick the system format default.

        Returns:
            A LocalTargetOutput descriptor instance.
        """
        self.cls = cls
        self.file_pattern = file_pattern
        self.format = format

    def __get__(self, task, cls):
        """ Attribute access method of descriptor.

        Args:
            task: class instance of host class when called via a host class' instance;
                None when called via the host class
            cls: host class object

        Returns:
            The LocalTargetOutput descriptor instance when accessed via the host class;
            or a function that implements "output()" when accessed via a host class instance.
        """
        if task is None:
            return self
        return lambda: self(task)

    def __call__(self, task):
        """ Implements the "output()" method of a Luigi Task.

        This method allows the descriptor to be used as "output" composition of a Luigi Task.
        A LocalTarget (or subsclass) is instantiated and returned. The "file_pattern" template is
        also evaluated here.

        Args:
            task: host class instance

        Returns:
            A Luigi LocalTarget (or subclass) instance.
        """
        return self.cls(self.file_pattern.format(task=task), format=self.format)
