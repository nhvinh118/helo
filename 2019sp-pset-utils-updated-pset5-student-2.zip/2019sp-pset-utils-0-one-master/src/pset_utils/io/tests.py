#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `pset_utils.io` package."""

import os
from tempfile import TemporaryDirectory
from unittest import TestCase

from ..io import atomic_write
from ..io import xlsx_to_parquet
import pandas
import pathlib

class FakeFileFailure(IOError):
    pass


class AtomicWriteTests(TestCase):

    def test_atomic_write(self):
        """Ensure file exists after being written successfully"""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            with atomic_write(fp, 'w') as f:
                assert not os.path.exists(fp)
                tmpfile = f.name
                f.write('asdf')

            assert not os.path.exists(tmpfile)
            assert os.path.exists(fp)

            with open(fp) as f:
                self.assertEqual(f.read(), 'asdf')

    def test_atomic_failure(self):
        """Ensure that file does not exist after failure during write"""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            with self.assertRaises(FakeFileFailure):
                with atomic_write(fp, 'w') as f:
                    tmpfile = f.name
                    assert os.path.exists(tmpfile)
                    raise FakeFileFailure()

            assert not os.path.exists(tmpfile)
            assert not os.path.exists(fp)

    def test_file_exists(self):
        """Ensure an error is raised when a file exists"""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')
            with open(fp, 'w') as f:
                pass

            with self.assertRaises(FileExistsError):
                with atomic_write(fp, 'w') as f:
                    pass


    def test_overwrite(self):
        """When overwrite=True, atomic_write should succeed even if file exists."""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')
            with open(fp, 'w') as f:
                pass

            with atomic_write(fp, 'w', overwrite=True) as f:
                tmpfile = f.name
                f.write('asdf')

            assert not os.path.exists(tmpfile)
            assert os.path.exists(fp)


    def test_atomic_write_pause(self):
        """Ensure file does not get transferred until context is exited".
           This test closes the file but may continue processing and then
           reopens the temp file. The temp file is expected to stay in place
           and does NOT get transferred to the destination."""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            with atomic_write(fp, 'w') as f:
                assert not os.path.exists(fp)
                tmpfile = f.name
                f.write('asdf')
                f.close()
                assert not os.path.exists(fp)
                assert os.path.exists(tmpfile)

            with open(fp) as f:
                self.assertEqual(f.read(), 'asdf')


    def test_atomic_write_as_file_false(self):
        """This tests as_file=False.
           Ensure a string is returned and points to a closed file that exists.
           This file is ready to be written to inside the context."""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            with atomic_write(fp, 'w', as_file=False) as tmpfile:
                assert not os.path.exists(fp)
                assert isinstance(tmpfile, str)
                assert os.path.exists(tmpfile)

                f = open(tmpfile, 'w')
                f.write('asdf')
                f.close()

            assert os.path.exists(fp)
            assert not os.path.exists(tmpfile)

            with open(fp) as f:
                self.assertEqual(f.read(), 'asdf')


    def test_atomic_write_r_a_mode(self):
        """atomic_write does not support "r" or "a" mode. An exception ie expected."""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            with self.assertRaises(ValueError):
                with atomic_write(fp, 'r') as f:
                    pass

            with self.assertRaises(ValueError):
                with atomic_write(fp, 'a') as f:
                    pass


    def test_atomic_write_same_directory(self):
        """Ensures that the temp file and the target are in the same directory.
           This is maximizes the chance of them being on the same file system."""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            with atomic_write(fp, 'w') as f:
                temp_file_directory = pathlib.Path(f.name).absolute().parent
                target_file_directory = pathlib.Path(fp).absolute().parent
                self.assertEqual(temp_file_directory, target_file_directory)


    def test_atomic_write_extension(self):
        """Ensures that temp file extension is the same as the target."""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.tar.gz')

            with atomic_write(fp, 'w') as f:
                temp_file_extension = ".".join(f.name.split('.')[1:])
                target_file_extension = ".".join(fp.split('.')[1:])
                self.assertEqual(temp_file_extension, target_file_extension)


    def test_atomic_write_new_temp_file(self):
        """Ensures that the temp file name is different if the process fails and then
           retries."""

        with TemporaryDirectory() as tmp:
            fp = os.path.join(tmp, 'asdf.txt')

            try:
                with atomic_write(fp, 'w') as f:
                    first_temp_file_name = f.name
                    raise FakeFileFailure
            except FakeFileFailure:
                pass

            try:
                with atomic_write(fp, 'w') as f:
                    second_temp_file_name = f.name
                    raise FakeFileFailure
            except FakeFileFailure:
                pass

        self.assertNotEqual(first_temp_file_name, second_temp_file_name)



    def test_xlsx_to_parquet_extension(self):
        """Ensures that the parquet file name is renamed correctly."""
        with TemporaryDirectory() as tmp:
            df = pandas.DataFrame({"c1": [1, 2, 3], "c2": [4, 5, 6]})

            # generate excel file
            fp = os.path.join(tmp, 'asdf.xlsx')
            df.to_excel(fp)

            parquet_file = xlsx_to_parquet(fp)
            self.assertEqual(pathlib.Path(parquet_file).name, "asdf.parquet")


    def test_xlsx_to_parquet_data_correctness(self):
        """Ensures that the parquet file has the correct content."""
        with TemporaryDirectory() as tmp:
            df = pandas.DataFrame({"c1": [1, 2, 3], "c2": [4, 5, 6]})

            # generate excel file
            fp = os.path.join(tmp, 'asdf.xlsx')
            df.to_excel(fp)

            # read back from the generated excel file to be sure
            excel_file_df = pandas.read_excel(fp)
            parquet_file = xlsx_to_parquet(fp)

            parquet_file_df = pandas.read_parquet(parquet_file)

            assert excel_file_df.equals(parquet_file_df)

    def test_xlsx_to_parquet_is_atomic(self):
        """Ensures that the atomic_write is used during parquet file conversion.

           Here we make use of the fact (from documentation) that to_parquet()
           throws an error when there are non-string column names.

           We check that the target file is not created in this case."""

        with TemporaryDirectory() as tmp:
            # make a column with non-string column name
            # to ensure to_parquet() throws an exception during write
            df = pandas.DataFrame({"c1": [1, 2, 3], 10: [4, 5, 6]})

            # generate excel file
            fp = os.path.join(tmp, 'asdf.xlsx')
            df.to_excel(fp)

            try:
                parquet_file = xlsx_to_parquet(fp)
            except ValueError:
                # this is expected as we give to_parquet() some unsupported content
                pass

            target_file_name = os.path.join(tmp, 'asdf.parquet')
            assert not os.path.exists(target_file_name)
