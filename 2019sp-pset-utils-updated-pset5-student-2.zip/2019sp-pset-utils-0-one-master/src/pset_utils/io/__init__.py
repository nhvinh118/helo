from contextlib import contextmanager
import tempfile
import pathlib
import pandas
from atomicwrites import atomic_write as _backend_writer, AtomicWriter

class SuffixWriter(AtomicWriter):
    """ A helper class for performing atomic writes.

    This class subclasses from atomicwrites.AtomicWriter so that some methods
    get_fileobject() and sync() can be overridden.
    These methods need to be overridden in order to support "as_file=False" and
    suffix preservation.

    For further details, see atomicwrites.AtomicWriter.
    """

    def get_fileobject(self, suffix="", prefix=tempfile.template,
                       dir=None, **kwargs):
        """Return the temporary file to use.

        This method overrides the AtomicWriter's one to support suffix preservation.
        The argument "suffix" is treated differently (see below). All other arguments
        are unused and are passed unmodified to the super class's method.
        For further details, see atomicwrites.AtomicWriter::get_fileobject().

        Args:
            suffix: str, if not specified, this method will use the target file
            name as suffix so that the temp will will have the same suffix.

        Returns:
            The method simply returns whatever the super class's method returns.
        """

        # get the base name of the file, this will handle cases where input is
        # string or PathLike
        target_file = pathlib.Path(self._path)

        target_file_name = target_file.name

        if suffix == "":
            new_suffix = "_partial_"+target_file_name

        return super().get_fileobject(suffix=new_suffix,
                                      prefix=prefix, dir=dir, **kwargs)

    def sync(self, f):
        """ Responsible for clearing as many file caches as possible before
        commit.

        This method overrides the AtomicWriter's one to support "as_file=False". In this
        case, the opening and closing of the temp file is handled by the caller (functions
        that execute inside the context). The yielded object is a file name, not a file object.
        Occasionally, the temp file can be in a closed state. We have to be able to handle this
        situation by overriding this method.
        For futher details, see overwrites.AtomicWriter::sync().

        Args:
            f: file object

        Returns:
            The method simply returns whatever the super class's method returns.
        """
        if not f.closed:
            return super().sync(f)

@contextmanager
def atomic_write(file, mode='w', as_file=True, **kwargs):
    """Write a file atomically

    This function is decorated as a context manager and only move temporary file
    to the destination after writing has completed.

    The input file can be specified as an absolute path or relative path.

    The function creates a temp file in the same directory as the intended target.
    It uses atomicwrites module to generate unique file names as well as to manage
    commits. The atomicwrites module also takes care of cleaning up in case of
    exceptions. The suffixes are preserved so user can easily identify the file
    types that are in progress.

    The file modes "a" and "r" are not supported. The use of them will result
    in an exception.

    Example:
        with atomic_write("hello.txt") as f:
            f.write("world!")

    Args:
        file: str or os.PathLike, target to write
        mode: str specifying file open mode, "a" and "r" are not supported
        as_file: bool, if True, the yielded object is a File
        (eg, what you get with `open(...)`).  Otherwise, it will be the
        temporary file path string
        kwargs: anything else needed to open the file, passed to NamedTemporaryFile
            if as_file = True

    Raises:
        FileExistsError: if target exists
        NotImplementedError: if mode is "a" or "r"

    """

    with _backend_writer(file, SuffixWriter, mode=mode, **kwargs) as t:

        temp_file_path = pathlib.Path(t.name)

        if as_file:
            yield t
        else:
            t.close() # close file so it can be reopened when we yield
            yield str(temp_file_path.absolute())

def xlsx_to_parquet(xlsx_file):
    """ Converts and excel file to parquet format.

    This function does the conversion atomically. The new file
    is placed in the same directory as the input. The output file name
    has a ".parquet" extension. The input can be specified as relative
    or absolute paths.

    Args:
        xlsx_file: a string or filelike object specifying the
            input excel file

    Returns:
        A string containing the full path name of the newly generated
            parquet file.

    """

    # can handle relative and absolute paths
    xlsx_file = pathlib.Path(xlsx_file)
    xlsx_file_name = xlsx_file.name
    xlsx_file_dir = xlsx_file.absolute().parent

    name_segments = xlsx_file_name.split(".")
    if len(name_segments) > 1:
        name_segments[-1] = "parquet"
    else:
        name_segments.append("parquet")
    target_file_name = ".".join(name_segments)

    target_file = str(xlsx_file_dir.joinpath(target_file_name))

    df = pandas.read_excel(xlsx_file)

    # make sure our write is done atomically!!
    with atomic_write(target_file, as_file=False) as temp_file:
        df.to_parquet(temp_file, compression='gzip')

    return target_file
